(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _request_request_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./request/request.component */ "./src/app/request/request.component.ts");
/* harmony import */ var _internal_internal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./internal/internal.component */ "./src/app/internal/internal.component.ts");
/* harmony import */ var _password_password_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./password/password.component */ "./src/app/password/password.component.ts");
/* harmony import */ var _passwordf_passwordf_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./passwordf/passwordf.component */ "./src/app/passwordf/passwordf.component.ts");
/* harmony import */ var _pending_pending_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pending/pending.component */ "./src/app/pending/pending.component.ts");
/* harmony import */ var _issue_issue_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./issue/issue.component */ "./src/app/issue/issue.component.ts");
/* harmony import */ var _internal_items_internal_items_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./internal-items/internal-items.component */ "./src/app/internal-items/internal-items.component.ts");
/* harmony import */ var _please_please_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./please/please.component */ "./src/app/please/please.component.ts");
/* harmony import */ var _please1_please1_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./please1/please1.component */ "./src/app/please1/please1.component.ts");
/* harmony import */ var _please2_please2_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./please2/please2.component */ "./src/app/please2/please2.component.ts");















const routes = [
    { path: '', component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"] },
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"] },
    { path: 'home', component: _request_request_component__WEBPACK_IMPORTED_MODULE_3__["RequestComponent"] },
    { path: 'internal', component: _internal_internal_component__WEBPACK_IMPORTED_MODULE_4__["InternalComponent"] },
    { path: 'password', component: _password_password_component__WEBPACK_IMPORTED_MODULE_5__["PasswordComponent"] },
    { path: 'passwordf', component: _passwordf_passwordf_component__WEBPACK_IMPORTED_MODULE_6__["PasswordfComponent"] },
    { path: 'pending', component: _pending_pending_component__WEBPACK_IMPORTED_MODULE_7__["PendingComponent"] },
    { path: 'issue', component: _issue_issue_component__WEBPACK_IMPORTED_MODULE_8__["IssueComponent"] },
    { path: 'internal-items', component: _internal_items_internal_items_component__WEBPACK_IMPORTED_MODULE_9__["InternalItemsComponent"] },
    { path: 'loading', component: _please_please_component__WEBPACK_IMPORTED_MODULE_10__["PleaseComponent"] },
    { path: 'loadinga', component: _please1_please1_component__WEBPACK_IMPORTED_MODULE_11__["Please1Component"] },
    { path: 'loadingb', component: _please2_please2_component__WEBPACK_IMPORTED_MODULE_12__["Please2Component"] },
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng-uikit-pro-standard */ "./node_modules/ng-uikit-pro-standard/__ivy_ngcc__/fesm2015/ng-uikit-pro-standard.js");





class AppComponent {
    constructor(router, toast) {
        this.router = router;
        this.toast = toast;
        this.title = 'edocs';
        this.sessionValue = "";
    }
    logout() {
        sessionStorage.removeItem("second");
        localStorage.removeItem("first");
        localStorage.removeItem("pass");
        localStorage.removeItem("order");
        this.router.navigateByUrl('/login');
    }
    goToHome() {
        localStorage.removeItem("order");
        this.router.navigateByUrl('/home');
    }
    goToInternal() {
        this.router.navigateByUrl('/internal');
    }
    goToIssue() {
        this.router.navigateByUrl('/issue');
    }
    goToEd() {
        this.router.navigateByUrl('/');
    }
    goToEss() {
        this.router.navigateByUrl('/');
    }
    goToEmails() {
        this.router.navigateByUrl('/');
    }
    get modalFormAvatarPassword() {
        return this.validatingForm.get('modalFormAvatarPassword');
    }
    ngOnInit() {
        this.validatingForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormGroup"]({
            modalFormAvatarPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required)
        });
        this.sessionValue = localStorage.getItem("first");
        if (this.sessionValue == null) {
            this.name = "Login";
        }
        else {
            this.name = "Logout";
        }
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_3__["ToastService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 36, vars: 1, consts: [[1, "navbar", "navbar-expand-lg", "navbar-dark", "color-b"], [1, "navbar-brand", 3, "click"], ["type", "button", "data-toggle", "collapse", "data-target", "#navbarText", "aria-controls", "navbarText", "aria-expanded", "false", "aria-label", "Toggle navigation", 1, "navbar-toggler"], [1, "navbar-toggler-icon"], ["id", "navbarText", 1, "collapse", "navbar-collapse"], [1, "navbar-nav", "mr-auto"], [1, "nav-item", "active"], [1, "nav-link", 3, "click"], [1, "sr-only"], [1, "nav-item"], ["href", "http://192.168.100.120:8080/edelphynbb", "target", "_blank", 1, "nav-link"], ["href", "http://192.168.100.13/ess", "target", "_blank", 1, "nav-link"], ["href", "https://nbsz.utande.co.zw", "target", "_blank", 1, "nav-link"], [1, "navbar-text", "white-text"], [3, "click"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nav", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_a_click_1_listener() { return ctx.goToHome(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Requisitions");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ul", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_a_click_8_listener() { return ctx.goToHome(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Home ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "(current)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_a_click_13_listener() { return ctx.goToInternal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Internal Order ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "(current)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_a_click_18_listener() { return ctx.goToIssue(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Issue Out ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "(current)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "li", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "e-Delphyn");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "li", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "ESS");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "li", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Emails");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, " ICT always make easier | ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "a", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_Template_a_click_33_listener() { return ctx.logout(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](35, "router-outlet");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.name);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]], styles: [".color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MseUJBQUE7QUFDRCIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb2xvci1ie1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICM4MzA5MDk7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_3__["ToastService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _request_request_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./request/request.component */ "./src/app/request/request.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _password_password_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./password/password.component */ "./src/app/password/password.component.ts");
/* harmony import */ var _internal_internal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./internal/internal.component */ "./src/app/internal/internal.component.ts");
/* harmony import */ var _pending_pending_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pending/pending.component */ "./src/app/pending/pending.component.ts");
/* harmony import */ var _issue_issue_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./issue/issue.component */ "./src/app/issue/issue.component.ts");
/* harmony import */ var _internal_items_internal_items_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./internal-items/internal-items.component */ "./src/app/internal-items/internal-items.component.ts");
/* harmony import */ var _please_please_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./please/please.component */ "./src/app/please/please.component.ts");
/* harmony import */ var _passwordf_passwordf_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./passwordf/passwordf.component */ "./src/app/passwordf/passwordf.component.ts");
/* harmony import */ var _please1_please1_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./please1/please1.component */ "./src/app/please1/please1.component.ts");
/* harmony import */ var ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ng-uikit-pro-standard */ "./node_modules/ng-uikit-pro-standard/__ivy_ngcc__/fesm2015/ng-uikit-pro-standard.js");
/* harmony import */ var _please2_please2_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./please2/please2.component */ "./src/app/please2/please2.component.ts");























class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"],
            angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MDBBootstrapModule"].forRoot(),
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_18__["ToastModule"].forRoot(),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
        _request_request_component__WEBPACK_IMPORTED_MODULE_8__["RequestComponent"],
        _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"],
        _password_password_component__WEBPACK_IMPORTED_MODULE_10__["PasswordComponent"],
        _internal_internal_component__WEBPACK_IMPORTED_MODULE_11__["InternalComponent"],
        _pending_pending_component__WEBPACK_IMPORTED_MODULE_12__["PendingComponent"],
        _issue_issue_component__WEBPACK_IMPORTED_MODULE_13__["IssueComponent"],
        _internal_items_internal_items_component__WEBPACK_IMPORTED_MODULE_14__["InternalItemsComponent"],
        _please_please_component__WEBPACK_IMPORTED_MODULE_15__["PleaseComponent"],
        _passwordf_passwordf_component__WEBPACK_IMPORTED_MODULE_16__["PasswordfComponent"],
        _please1_please1_component__WEBPACK_IMPORTED_MODULE_17__["Please1Component"],
        _please2_please2_component__WEBPACK_IMPORTED_MODULE_19__["Please2Component"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MDBRootModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_18__["ToastModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
                    _request_request_component__WEBPACK_IMPORTED_MODULE_8__["RequestComponent"],
                    _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"],
                    _password_password_component__WEBPACK_IMPORTED_MODULE_10__["PasswordComponent"],
                    _internal_internal_component__WEBPACK_IMPORTED_MODULE_11__["InternalComponent"],
                    _pending_pending_component__WEBPACK_IMPORTED_MODULE_12__["PendingComponent"],
                    _issue_issue_component__WEBPACK_IMPORTED_MODULE_13__["IssueComponent"],
                    _internal_items_internal_items_component__WEBPACK_IMPORTED_MODULE_14__["InternalItemsComponent"],
                    _please_please_component__WEBPACK_IMPORTED_MODULE_15__["PleaseComponent"],
                    _passwordf_passwordf_component__WEBPACK_IMPORTED_MODULE_16__["PasswordfComponent"],
                    _please1_please1_component__WEBPACK_IMPORTED_MODULE_17__["Please1Component"],
                    _please2_please2_component__WEBPACK_IMPORTED_MODULE_19__["Please2Component"]
                ],
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"],
                    angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MDBBootstrapModule"].forRoot(),
                    _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                    ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_18__["ToastModule"].forRoot(),
                ],
                providers: [],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/data/data.ts":
/*!******************************!*\
  !*** ./src/app/data/data.ts ***!
  \******************************/
/*! exports provided: declaredData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "declaredData", function() { return declaredData; });
class declaredData {
}


/***/ }),

/***/ "./src/app/data/restapi.service.ts":
/*!*****************************************!*\
  !*** ./src/app/data/restapi.service.ts ***!
  \*****************************************/
/*! exports provided: RestapiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestapiService", function() { return RestapiService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");






class RestapiService {
    constructor(http) {
        this.http = http;
        // Define API
        this.apiURL = "http://localhost:3000";
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_2__["declaredData"]();
    }
    handleError(error) {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
    /** POST: add a new owner to the database */
    sign(userData) {
        return this.http.post(this.apiURL + "/sign", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    add(userData) {
        return this.http.post(this.apiURL + "/adds", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    additems(userData) {
        return this.http.post(this.apiURL + "/additems", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /*Sign in of users*/
    userlogin(userData) {
        return this.http.post(this.apiURL + "/log", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    ownerDetails(userData) {
        return this.http.post(this.apiURL + "/ownerDetails", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    vehicle(userData) {
        return this.http.post(this.apiURL + "/vehicle", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    ///////////////////get Users//////////////////////////////////////////////
    user() {
        return this.http.get(this.apiURL + "/login");
    }
    /** POST: add a new owner to the database */
    addAdmin(userData) {
        return this.http.post(this.apiURL + "/addAdmin", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    changePassword(userData) {
        return this.http.post(this.apiURL + "/changePassword", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    tempPassword(userData) {
        return this.http.post(this.apiURL + "/tempPassword", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    getData(Emails) {
        this.declared.Email = Emails;
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('Email', Emails);
        console.log(params.toString());
        return this.http.get(this.apiURL + "/allData" + '/' + Emails);
    }
    getDataToIssue(Emails, Dpt) {
        this.declared.Email = Emails;
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('Email', Emails);
        console.log(params.toString());
        return this.http.get(this.apiURL + "/allDataToIssue" + '/' + Emails + '/' + Dpt);
    }
    getPendingData(Emails) {
        this.declared.Email = Emails;
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('Email', Emails);
        console.log(params.toString());
        return this.http.get(this.apiURL + "/allPendingData" + '/' + Emails);
    }
    getDpt(Emails) {
        this.declared.Email = Emails;
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]()
            .set('Email', Emails);
        console.log(params.toString());
        return this.http.get(this.apiURL + "/dpt" + '/' + Emails);
    }
    getOrder() {
        return this.http.get(this.apiURL + "/order");
    }
    getAp(ID_Key) {
        return this.http.get(this.apiURL + "/approveR" + '/' + ID_Key);
    }
    getIs(ID_Key) {
        return this.http.get(this.apiURL + "/issueR" + '/' + ID_Key);
    }
    getReject(ID_Key) {
        return this.http.get(this.apiURL + "/issueR" + '/' + ID_Key);
    }
    /** POST: add a new owner to the database */
    setNewPass(userData) {
        return this.http.post(this.apiURL + "/setNewPass", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
    /** POST: add a new owner to the database */
    approve(userData) {
        return this.http.post(this.apiURL + "/approve", userData, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    }
}
RestapiService.ɵfac = function RestapiService_Factory(t) { return new (t || RestapiService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
RestapiService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: RestapiService, factory: RestapiService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](RestapiService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/internal-items/internal-items.component.ts":
/*!************************************************************!*\
  !*** ./src/app/internal-items/internal-items.component.ts ***!
  \************************************************************/
/*! exports provided: InternalItemsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InternalItemsComponent", function() { return InternalItemsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class InternalItemsComponent {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
        this.sessionValue = "";
        this.localValue = "";
        this.order = "";
        this.s = '"';
        this.rw = '';
    }
    ngOnInit() {
        this.sessionValue = localStorage.getItem("first");
        this.order = localStorage.getItem("order");
        if (this.sessionValue == null) {
            this.router.navigateByUrl('/login');
        }
        else {
            this.r = this.order.split(this.s).join(this.rw);
            console.log("Nicole " + this.r);
            this.declared.ID_Key = this.r;
            console.log("Nicole " + this.declared.ID_Key);
        }
    }
    onClickSubmit() {
        console.log("richy the new Id is" + this.order);
        console.log(this.declared);
        this.restApi.additems(this.declared)
            .subscribe(data => console.log("Succeeded, result = " + data), (err) => console.error("Failed! " + err));
    }
    goTointernal() {
        localStorage.removeItem("order");
        this.router.navigateByUrl('/internal');
    }
}
InternalItemsComponent.ɵfac = function InternalItemsComponent_Factory(t) { return new (t || InternalItemsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
InternalItemsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: InternalItemsComponent, selectors: [["app-internal-items"]], decls: 42, vars: 4, consts: [[1, "b"], [1, ""], [1, "a"], [1, "color-b", "white-text", "text-center", "py-4"], [1, "px-lg-5"], [1, "text-center", 2, "color", "#757575", 3, "ngSubmit"], ["userLogin", "ngForm"], [1, "md-form", "mt-3"], ["type", "text", "name", "Description", "id", "materialSubscriptionFormDes", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormDes"], ["type", "number", "name", "Quantity", "id", "materialSubscriptionFormAQua", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormAQua"], ["type", "text", "name", "Comment", "id", "materialSubscriptionFormComment", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormComment"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", "type", "submit", 1, "z-depth-0", "my-4", "waves-effect"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", 1, "z-depth-0", "my-4", "waves-effect", 3, "click"], ["href", ""], [1, "footer"], [1, "h", "ah"], [1, "h"]], template: function InternalItemsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mdb-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mdb-card-header", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Internal Order Items ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mdb-card-body", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "form", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function InternalItemsComponent_Template_form_ngSubmit_12_listener() { return ctx.onClickSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "code");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Please in the following form ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalItemsComponent_Template_input_ngModelChange_18_listener($event) { return ctx.declared.Description = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalItemsComponent_Template_input_ngModelChange_22_listener($event) { return ctx.declared.Quantity = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "label", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "Quantity");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalItemsComponent_Template_input_ngModelChange_26_listener($event) { return ctx.declared.Comment = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Comment");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Submit");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function InternalItemsComponent_Template_button_click_31_listener() { return ctx.goTointernal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "New Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Forgot Password? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "a", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "Reset");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "p", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "p", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Order number ", ctx.r, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Description);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Quantity);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Comment);
    } }, directives: [angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardHeaderComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardBodyComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NumberValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["WavesDirective"]], styles: [".a[_ngcontent-%COMP%] {\n  width: 60%;\n  padding: 0% 15%;\n  margin: 0% 20%;\n}\n\n.color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n\n.footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 130%;\n  background-image: url('plain2.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW50ZXJuYWwtaXRlbXMvaW50ZXJuYWwtaXRlbXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxVQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFDRDs7QUFDQTtFQUNDLHlCQUFBO0FBRUQ7O0FBQUE7RUFDQyxXQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO0FBR0Q7O0FBREE7RUFDQyxzQkFBQTtBQUlEOztBQUZBO0VBQ0Msa0JBQUE7QUFLRDs7QUFIQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQU1EOztBQUpBO0VBQ0MsWUFBQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQU9EOztBQUxBO0VBQ0MsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0FBUUQiLCJmaWxlIjoic3JjL2FwcC9pbnRlcm5hbC1pdGVtcy9pbnRlcm5hbC1pdGVtcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5he1xyXG5cdHdpZHRoOiA2MCU7XHJcblx0cGFkZGluZzogMCUgMTUlO1xyXG5cdG1hcmdpbjogMCUgMjAlO1xyXG59XHJcbi5jb2xvci1ie1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICM4MzA5MDk7XHJcbn1cclxuLmZvb3RlcntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHNpbHZlcjtcclxufVxyXG4uYWh7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxufVxyXG4uaHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmJ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMzAlO1xyXG5cdGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL3BsYWluMi5qcGcnKTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG5cdGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcblx0YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuXHRvcGFjaXR5OiAwLjk7XHJcbn1cclxuLmFwe1xyXG5cdGNvbG9yOiBibGFjaztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCAjODMwOTA5O1xyXG5cdGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuLmFwOmhvdmVye1xyXG5cdGNvbG9yOiB3aGl0ZTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjODMwOTA5O1xyXG5cdGJvcmRlcjoxcHggc29saWQgYmxhY2s7XHJcblx0Ym9yZGVyLXJhZGl1czogMTBweDtcclxuXHRib3gtc2hhZG93OiAxMHB4IDEwcHggMTBweCBibGFjaztcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](InternalItemsComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-internal-items',
                templateUrl: './internal-items.component.html',
                styleUrls: ['./internal-items.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/internal/internal.component.ts":
/*!************************************************!*\
  !*** ./src/app/internal/internal.component.ts ***!
  \************************************************/
/*! exports provided: InternalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InternalComponent", function() { return InternalComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class InternalComponent {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
        this.sessionValue = "";
        this.localValue = "";
        this.order1 = "";
    }
    ngOnInit() {
        this.sessionValue = localStorage.getItem("first");
        if (this.sessionValue == null) {
            this.router.navigateByUrl('/login');
        }
        else {
            this.declared.RequestedByEmail = this.sessionValue;
        }
    }
    onClickSubmit() {
        console.log(this.declared);
        this.restApi.add(this.declared)
            .subscribe(data => localStorage.setItem("order", JSON.stringify(data)), (err) => console.error("Failed! " + err));
        this.router.navigateByUrl('/loading');
    }
}
InternalComponent.ɵfac = function InternalComponent_Factory(t) { return new (t || InternalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
InternalComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: InternalComponent, selectors: [["app-internal"]], decls: 50, vars: 6, consts: [[1, "b"], [1, ""], [1, "a"], [2, "opacity", "0.7"], [1, "color-b", "white-text", "text-center", "py-4"], [1, "px-lg-5"], [1, "text-center", 2, "color", "#757575", 3, "ngSubmit"], ["userLogin", "ngForm"], [1, "md-form", "mt-3"], ["type", "text", "name", "RequestedBy", "id", "materialSubscriptionFormName", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormname"], ["type", "email", "name", "AuthorisedBy", "id", "materialSubscriptionFormAName", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormAname"], ["type", "text", "name", "DptFrom", "id", "materialSubscriptionFormDepartment", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormDepartment"], ["type", "text", "name", "DptTo", "id", "materialSubscriptionFormDepartmentTo", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormDepartmentTo"], ["type", "text", "name", "Branch", "id", "materialSubscriptionFormBranch", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormBranch"], ["type", "date", "name", "Date", "id", "materialSubscriptionFormR", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormR"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", "type", "submit", 1, "z-depth-0", "my-4", "waves-effect"], ["href", ""], [1, "footer"], [1, "h", "ah"], [1, "h"]], template: function InternalComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mdb-card", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mdb-card-header", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Internal Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mdb-card-body", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "form", 6, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function InternalComponent_Template_form_ngSubmit_10_listener() { return ctx.onClickSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "code");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Please fill in the following form ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_16_listener($event) { return ctx.declared.RequestedBy = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "label", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Name(eg Emma Chimuti)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_20_listener($event) { return ctx.declared.AuthorisedBy = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Authorisor's email");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_24_listener($event) { return ctx.declared.DptFrom = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Enter your department");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_28_listener($event) { return ctx.declared.DptTo = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Enter the receiving department");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_32_listener($event) { return ctx.declared.Branch = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Branch");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function InternalComponent_Template_input_ngModelChange_36_listener($event) { return ctx.declared.Date = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Submit");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Forgot Password? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "a", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "Reset");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "p", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "p", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.RequestedBy);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.AuthorisedBy);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.DptFrom);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.DptTo);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Branch);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Date);
    } }, directives: [angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardHeaderComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardBodyComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["WavesDirective"]], styles: [".a[_ngcontent-%COMP%] {\n  width: 60%;\n  padding: 0% 15%;\n  margin: 0% 20%;\n}\n\n.color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n\n.footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 130%;\n  background-image: url('plain2.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW50ZXJuYWwvaW50ZXJuYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxVQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFDRDs7QUFDQTtFQUNDLHlCQUFBO0FBRUQ7O0FBQUE7RUFDQyxXQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO0FBR0Q7O0FBREE7RUFDQyxzQkFBQTtBQUlEOztBQUZBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQ0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FBS0Q7O0FBSEE7RUFDQyxZQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBTUQ7O0FBSkE7RUFDQyxZQUFBO0VBQ0EseUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0NBQUE7QUFPRCIsImZpbGUiOiJzcmMvYXBwL2ludGVybmFsL2ludGVybmFsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF7XHJcblx0d2lkdGg6IDYwJTtcclxuXHRwYWRkaW5nOiAwJSAxNSU7XHJcblx0bWFyZ2luOiAwJSAyMCU7XHJcbn1cclxuLmNvbG9yLWJ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxufVxyXG4uZm9vdGVye1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwcHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogc2lsdmVyO1xyXG59XHJcbi5haHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xyXG59XHJcbi5ie1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTMwJTtcclxuXHRiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9wbGFpbjIuanBnJyk7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuXHRiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG5cdGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcblx0b3BhY2l0eTogMC45O1xyXG59XHJcbi5hcHtcclxuXHRjb2xvcjogYmxhY2s7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogc2lsdmVyO1xyXG5cdGJvcmRlcjoxcHggc29saWQgIzgzMDkwOTtcclxuXHRib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcbi5hcDpob3ZlcntcclxuXHRjb2xvcjogd2hpdGU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxuXHRib3JkZXI6MXB4IHNvbGlkIGJsYWNrO1xyXG5cdGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggYmxhY2s7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](InternalComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-internal',
                templateUrl: './internal.component.html',
                styleUrls: ['./internal.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/issue/issue.component.ts":
/*!******************************************!*\
  !*** ./src/app/issue/issue.component.ts ***!
  \******************************************/
/*! exports provided: IssueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IssueComponent", function() { return IssueComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-uikit-pro-standard */ "./node_modules/ng-uikit-pro-standard/__ivy_ngcc__/fesm2015/ng-uikit-pro-standard.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");










function IssueComponent_div_21_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "table", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Description");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Quantity");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Comment");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_div_21_Template_button_click_26_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](30); return _r2.show(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Issue Out ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 16, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "h5", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Order Key");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function IssueComponent_div_21_Template_input_ngModelChange_39_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r5.declared.Order = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Enter the order key");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_div_21_Template_button_click_43_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const data_r1 = ctx.$implicit; const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r6.verify(data_r1.ID_Key); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "Check ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](45, "mdb-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_div_21_Template_button_click_47_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const data_r1 = ctx.$implicit; const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r7.issue(data_r1.ID_Key); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Reject");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](49, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "code");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "-----end of request-------");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](52, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const data_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Requestor:", data_r1.RequestedBy, " (", data_r1.DptFrom, ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Department: ", data_r1.DptTo, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Date: ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](7, 11, data_r1.Date, "dd-MM-yyyy"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Authorised By:", data_r1.AuthorisedBy, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Description);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Quantity);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Comment);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r0.declared.Order);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", data_r1.ID_Key);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", data_r1.ID_Key);
} }
class IssueComponent {
    constructor(restApi, router, toast) {
        this.restApi = restApi;
        this.router = router;
        this.toast = toast;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.in = [];
        this.sessionValue = "";
        this.local = "";
        this.localValue = "";
        this.Em = "";
    }
    ngOnInit() {
        this.validatingForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            modalFormAvatarPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
        });
        this.sessionValue = localStorage.getItem("first");
        this.local = sessionStorage.getItem("second");
        if (this.sessionValue == null) {
            this.router.navigateByUrl('/login');
        }
        else {
            this.loadData();
        }
    }
    get modalFormAvatarPassword() {
        return this.validatingForm.get('modalFormAvatarPassword');
    }
    loadData() {
        console.log(this.sessionValue + "  and  " + this.local);
        return this.restApi.getDataToIssue(this.sessionValue, this.local)
            .subscribe(data => this.in = data);
    }
    goTOInternal() {
        this.router.navigateByUrl('/internal');
    }
    goToP() {
        this.router.navigateByUrl('/password');
    }
    goToPending() {
        this.go();
        this.router.navigateByUrl('/pending');
    }
    goToIssue() {
        this.go();
        this.router.navigateByUrl('/issue');
    }
    go() {
        sessionStorage.setItem("second", this.Em);
        this.localValue = sessionStorage.getItem("second");
        console.log("Department" + this.Em);
        console.log("Session Dot " + this.localValue);
    }
    issue(key) {
        return this.restApi.getIs(key)
            .subscribe(data => this.richy = data);
        console.log(key);
    }
    reject(key) {
        return this.restApi.getReject(key)
            .subscribe(data => this.richy = data);
        console.log(key);
    }
    verify(key) {
        this.declared.ID_Key = key;
        console.log(this.declared);
        if (this.declared.ID_Key == this.declared.Order) {
            // code...
            sessionStorage.setItem("checkout", key);
            this.router.navigateByUrl('/loadingb');
        }
        else {
            setTimeout(() => this.toast.error('Order-number :' + this.declared.Order + ' do not match the checked order '));
        }
    }
}
IssueComponent.ɵfac = function IssueComponent_Factory(t) { return new (t || IssueComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_5__["ToastService"])); };
IssueComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: IssueComponent, selectors: [["app-issue"]], decls: 39, vars: 3, consts: [[2, "background-color", "silver"], [1, "", 2, "width", "100%", "box-shadow", "15px 15px 15px silver", "color", "#830909"], ["id", "movetxt"], [1, "h"], [1, "maindiv"], [1, "left"], [1, "ap", 3, "click"], [1, "center"], [1, "card-body"], [1, "card", "richy", "example-1", "scrollbar-ripe-malinka", "bordered-deep-purple", "thin"], [4, "ngFor", "ngForOf"], [1, "right"], [1, "footer"], [1, "h", "ah"], [1, "table", "table-striped", "w-auto"], ["type", "button", "data-toggle", "modal", "data-target", "#basicExample", "mdbWavesEffect", "", 1, "ap", 3, "click"], ["mdbModal", "", "id", "frameModalTop", "tabindex", "-1", "role", "dialog", "aria-labelledby", "myModalLabel", "aria-hidden", "true", 1, "modal", "fade", "top"], ["frame", "mdbModal"], ["role", "document", 1, "modal-dialog", "cascading-modal", "modal-avatar", "modal-sm"], [1, "modal-content"], [1, "modal-header"], ["src", "./assets/NBSZ.png", "alt", "avatar", 1, "rounded-circle", "img-responsive"], [1, "modal-body", "mb-1"], [1, "mt-1", "mb-2", "text-center"], [1, "md-form", "ml-0", "mr-0"], ["type", "password", "type", "text", "id", "form29", "name", "Order", "mdbInput", "", 1, "form-control", "form-control-sm", "ml-0", 3, "ngModel", "ngModelChange"], ["for", "form29", 1, "ml-0"], [1, "text-center", "mt-4"], ["mdbBtn", "", "color", "cyan", "rounded", "true", "type", "submit", "mdbWavesEffect", "", 1, "mt-1", "waves-light", 3, "value", "click"], ["fas", "", "icon", "sign-in-alt", 1, "ml-1"], [1, "ap", 3, "value", "click"]], template: function IssueComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Life is in the Blood ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "h4", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h5", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " ISSUE OUT");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_Template_button_click_13_listener() { return ctx.goToP(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Issue out");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](21, IssueComponent_div_21_Template, 53, 14, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "Make a request");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_Template_button_click_25_listener() { return ctx.goTOInternal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Internal Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](27, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_Template_button_click_28_listener() { return ctx.goToPending(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Pending .");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function IssueComponent_Template_button_click_31_listener() { return ctx.goToIssue(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Issue out");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Eplore the World | ", ctx.sessionValue, "| ", ctx.declared.Email, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.in);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["WavesDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["ModalDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgModel"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["MdbIconComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_7__["FasDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__["DatePipe"]], styles: [".footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 120%;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n\n.spacer[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n}\n\n#form[_ngcontent-%COMP%] {\n  background-color: white;\n  border: 1px solid green;\n  text-align: center;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%] {\n  color: #00134d;\n  background-color: white;\n  border: 1px solid green;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%]:hover {\n  background-color: green;\n  color: white;\n}\n\n.slidera[_ngcontent-%COMP%] {\n  height: 500px;\n}\n\n.head[_ngcontent-%COMP%] {\n  margin: 5%;\n}\n\n.head1[_ngcontent-%COMP%] {\n  background-color: #f5f5ef;\n  height: 70px;\n  width: 100%;\n}\n\n.main[_ngcontent-%COMP%] {\n  height: auto;\n  width: 100%;\n  background-color: transparent;\n  background-color: #f5f5ef;\n}\n\n.first[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  border-radius: 5px;\n  margin: 2% 2%;\n  padding: 2%;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.second[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 1%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.third[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 2%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s1[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s2[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.first[_ngcontent-%COMP%]:hover, .first1[_ngcontent-%COMP%]:hover, .second[_ngcontent-%COMP%]:hover, .second1[_ngcontent-%COMP%]:hover, .third[_ngcontent-%COMP%]:hover {\n  border: 2px solid #006699;\n  box-shadow: 15px 15px 15px #006699;\n  background-color: white;\n  color: #00134d;\n}\n\n.btna[_ngcontent-%COMP%] {\n  margin: 2% 2%;\n  color: #00134d;\n  background-color: white;\n  border: 1px solid #00134d;\n  border-radius: 2px;\n}\n\n.btna[_ngcontent-%COMP%]:hover {\n  margin: 3% 3%;\n  color: green;\n  background-color: white;\n  border: 1px solid green;\n  border-radius: 2px;\n}\n\n.footerr[_ngcontent-%COMP%] {\n  height: 200px;\n  width: 100%;\n}\n\n#movetxt[_ngcontent-%COMP%] {\n  animation-duration: 20s;\n  animation-name: slidein;\n  animation-iteration-count: infinite;\n}\n\n@keyframes slidein {\n  from {\n    margin-left: 100%;\n    width: 300%;\n  }\n  to {\n    margin-left: 0%;\n    width: 100%;\n  }\n}\n\n.maindiv[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 400px;\n  background-color: transparent;\n  padding: 1%;\n}\n\n.left[_ngcontent-%COMP%] {\n  width: 16%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 1% 0%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.richy[_ngcontent-%COMP%] {\n  padding: 4%;\n}\n\n.center[_ngcontent-%COMP%] {\n  width: 53%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 0%;\n  box-shadow: 5px 5px 5px 5px;\n}\n\n.right[_ngcontent-%COMP%] {\n  width: 20%;\n  height: auto;\n  background-color: transparent;\n  float: right;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #512da8;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%] {\n  scrollbar-color: #512da8 #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #00bcd4;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%] {\n  scrollbar-color: #00bcd4 #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #d4fc79 0%, #96e6a1 100%);\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #f093fb 0%, #f5576c 100%);\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #512da8;\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #00bcd4;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  border-radius: 0 !important;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 0 !important;\n}\n\n.thin[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n\n.example-1[_ngcontent-%COMP%] {\n  position: relative;\n  overflow-y: scroll;\n  height: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaXNzdWUvaXNzdWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxXQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO0FBQ0Q7O0FBQ0E7RUFDQyxzQkFBQTtBQUVEOztBQUFBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FBR0Q7O0FBREE7RUFDQyxZQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBSUQ7O0FBRkE7RUFDQyxZQUFBO0VBQ0EseUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0NBQUE7QUFLRDs7QUFIQTtFQUNDLGNBQUE7QUFNRDs7QUFIQTtFQUNDLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsOEJBQUE7QUFNRDs7QUFKQTtFQUNDLGNBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSwrQkFBQTtBQU9EOztBQUxBO0VBQ0MsdUJBQUE7RUFDQSxZQUFBO0FBUUQ7O0FBTkE7RUFDQyxhQUFBO0FBU0Q7O0FBUEE7RUFDQyxVQUFBO0FBVUQ7O0FBUkE7RUFDQyx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBV0Q7O0FBVEE7RUFDQyxZQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EseUJBQUE7QUFZRDs7QUFWQTtFQUNDLFVBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7QUFhRDs7QUFWQTtFQUNDLFVBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7QUFhRDs7QUFUQTtFQUNDLFVBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7QUFZRDs7QUFUQTtFQUNDLGtCQUFBO0FBWUQ7O0FBVkE7RUFDQyxrQkFBQTtBQWFEOztBQVhBO0VBQ0Msc0JBQUE7QUFjRDs7QUFYQTtFQUNFLHlCQUFBO0VBQ0Qsa0NBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFjRDs7QUFaQTtFQUNDLGFBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBZUQ7O0FBWkM7RUFDQyxhQUFBO0VBQ0QsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQWVEOztBQWJDO0VBQ0csYUFBQTtFQUNBLFdBQUE7QUFnQko7O0FBWkE7RUFDQyx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUNBQUE7QUFlRDs7QUFiQTtFQUNDO0lBQ0MsaUJBQUE7SUFDQSxXQUFBO0VBZ0JBO0VBZEQ7SUFDQyxlQUFBO0lBQ0EsV0FBQTtFQWdCQTtBQUNGOztBQWRBO0VBQ0MsV0FBQTtFQUNBLGFBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7QUFnQkQ7O0FBZEE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQWlCRDs7QUFaQTtFQUNDLFdBQUE7QUFlRDs7QUFiQTtFQUNDLFVBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7QUFnQkQ7O0FBZEE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQWlCRDs7QUFkQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQWlCQTs7QUFmQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQWtCQTs7QUFoQkE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7QUFtQkE7O0FBakJBO0VBQ0EsZ0NBQUE7QUFvQkE7O0FBakJBO0VBQ0Esb0RBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBb0JBOztBQWxCQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQXFCQTs7QUFuQkE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7QUFzQkE7O0FBcEJBO0VBQ0EsZ0NBQUE7QUF1QkE7O0FBcEJBO0VBQ0Esb0RBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBdUJBOztBQXJCQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQXdCQTs7QUF0QkE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBRUEsbUVBQUE7QUF5QkE7O0FBdkJBO0VBQ0Esb0RBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBMEJBOztBQXhCQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQTJCQTs7QUF6QkE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBRUEsbUVBQUE7QUE0QkE7O0FBMUJBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQTZCQTs7QUEzQkE7RUFDQSx3QkFBQTtBQThCQTs7QUE1QkE7RUFDQSx3QkFBQTtFQUNBLHlCQUFBO0FBK0JBOztBQTdCQTtFQUNBLHdCQUFBO0FBZ0NBOztBQTlCQTtFQUNBLDJCQUFBO0FBaUNBOztBQS9CQTtFQUNBLDJCQUFBO0FBa0NBOztBQWhDQTtFQUNBLFVBQUE7QUFtQ0E7O0FBakNBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUFvQ0EiLCJmaWxlIjoic3JjL2FwcC9pc3N1ZS9pc3N1ZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mb290ZXJ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMDBweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XHJcbn1cclxuLmFoe1xyXG5cdGJhY2tncm91bmQtY29sb3I6IGdyYXk7XHJcbn1cclxuLmJ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMjAlO1xyXG5cdGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuXHRiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG5cdGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcblx0b3BhY2l0eTogMC45O1xyXG59XHJcbi5hcHtcclxuXHRjb2xvcjogYmxhY2s7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogc2lsdmVyO1xyXG5cdGJvcmRlcjoxcHggc29saWQgIzgzMDkwOTtcclxuXHRib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcbi5hcDpob3ZlcntcclxuXHRjb2xvcjogd2hpdGU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxuXHRib3JkZXI6MXB4IHNvbGlkIGJsYWNrO1xyXG5cdGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggYmxhY2s7XHJcbn1cclxuLnNwYWNlcntcclxuXHRmbGV4OjEgMSBhdXRvO1xyXG59XHJcblxyXG4jZm9ybXtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCBncmVlbjtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Ym9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xyXG5cdGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxufVxyXG4uYnRuYWF7XHJcblx0Y29sb3I6IHJnYigwLDE5LDc3KTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCBncmVlbjtcclxuXHRib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xyXG5cdGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbn1cclxuLmJ0bmFhOmhvdmVye1xyXG5cdGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xyXG5cdGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uc2xpZGVyYXtcclxuXHRoZWlnaHQ6IDUwMHB4O1xyXG59XHJcbi5oZWFke1xyXG5cdG1hcmdpbjogNSU7XHJcbn1cclxuLmhlYWQxeztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQ1LDI0NSwyMzkpO1xyXG5cdGhlaWdodDogNzBweDtcclxuXHR3aWR0aDogMTAwJTtcclxufVxyXG4ubWFpbntcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwyNDUsMjM5KTtcclxufVxyXG4uZmlyc3R7XHJcblx0d2lkdGg6IDMwJTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IGxlZnQ7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdG1hcmdpbjogMiUgMiU7XHJcblx0cGFkZGluZzogMiU7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCByZ2IoMCwxOSw3Nyk7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggcmdiKDAsMTksNzcpO1xyXG59XHJcblxyXG4uc2Vjb25ke1xyXG5cdHdpZHRoOiAzMCU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdG1hcmdpbjogMiUgMSU7XHJcblx0cGFkZGluZzogMiU7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdGJvcmRlcjoxcHggc29saWQgcmdiKDAsMTksNzcpO1xyXG5cdGJveC1zaGFkb3c6IDEwcHggMTBweCAxMHB4IHJnYigwLDE5LDc3KTtcclxuXHJcbn1cclxuXHJcbi50aGlyZHtcclxuXHR3aWR0aDogMzAlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRtYXJnaW46IDIlIDIlO1xyXG5cdHBhZGRpbmc6IDIlO1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRib3JkZXI6MXB4IHNvbGlkIHJnYigwLDE5LDc3KTtcclxuXHRib3gtc2hhZG93OiAxMHB4IDEwcHggMTBweCByZ2IoMCwxOSw3Nyk7XHJcbn1cclxuXHJcbi5oe1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4uczF7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5zMntcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xyXG59XHJcblxyXG4uZmlyc3Q6aG92ZXIsLmZpcnN0MTpob3ZlciwgLnNlY29uZDpob3Zlciwuc2Vjb25kMTpob3ZlciwgLnRoaXJkOmhvdmVyIHtcclxuXHRcdGJvcmRlcjoycHggc29saWQgcmdiKDAsIDEwMiwgMTUzKTtcclxuXHRib3gtc2hhZG93OiAxNXB4IDE1cHggMTVweCByZ2IoMCwgMTAyLCAxNTMpO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG5cdGNvbG9yOiByZ2IoMCwxOSw3Nyk7XHJcbn1cclxuLmJ0bmF7XHJcblx0bWFyZ2luOiAyJSAyJTtcclxuXHRjb2xvcjogcmdiKDAsMTksNzcpO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIHJnYigwLDE5LDc3KTtcclxuXHRib3JkZXItcmFkaXVzOiAycHg7XHJcbn1cclxuXHJcbiAuYnRuYTpob3ZlcntcclxuIFx0bWFyZ2luOiAzJSAzJTtcclxuXHRjb2xvcjogZ3JlZW47XHJcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcblx0Ym9yZGVyLXJhZGl1czogMnB4O1xyXG4gfVxyXG4gLmZvb3RlcnJ7XHJcbiBcdCBcdGhlaWdodDogMjAwcHg7XHJcbiBcdCBcdHdpZHRoOiAxMDAlO1xyXG4gfVxyXG5cclxuIFxyXG4jbW92ZXR4dHtcclxuXHRhbmltYXRpb24tZHVyYXRpb246MjBzO1xyXG5cdGFuaW1hdGlvbi1uYW1lOiBzbGlkZWluO1xyXG5cdGFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6aW5maW5pdGU7XHJcbn1cclxuQGtleWZyYW1lcyBzbGlkZWlue1xyXG5cdGZyb217XHJcblx0XHRtYXJnaW4tbGVmdDogMTAwJTtcclxuXHRcdHdpZHRoOiAzMDAlO1xyXG5cdH1cclxuXHR0b3tcclxuXHRcdG1hcmdpbi1sZWZ0OiAwJTtcclxuXHRcdHdpZHRoOiAxMDAlO1xyXG5cdH1cclxufVxyXG4ubWFpbmRpdntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDQwMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdHBhZGRpbmc6IDElO1xyXG59XHJcbi5sZWZ0e1xyXG5cdHdpZHRoOiAxNiU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdG1hcmdpbjogMSUgMCU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgcmdiKDAsIDUxLCA3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdHBhZGRpbmc6IDElO1xyXG5cdFxyXG5cclxuXHJcbn1cclxuLnJpY2h5e1xyXG5cdHBhZGRpbmc6IDQlO1xyXG59XHJcbi5jZW50ZXJ7XHJcblx0d2lkdGg6IDUzJTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luOiAyJTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCByZ2IoMCwgNTEsIDc3KTtcclxuXHRib3JkZXItcmFkaXVzOiA1cHg7XHJcblx0cGFkZGluZzowJTtcclxuXHRib3gtc2hhZG93OiA1cHggNXB4IDVweCA1cHggO1xyXG59XHJcbi5yaWdodHtcclxuXHR3aWR0aDogMjAlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogcmlnaHQ7XHJcblx0bWFyZ2luOiAyJTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCByZ2IoMCwgNTEsIDc3KTtcclxuXHRib3JkZXItcmFkaXVzOiA1cHg7XHJcblx0cGFkZGluZzogMSU7XHJcblxyXG59XHJcbi5zY3JvbGxiYXItZGVlcC1wdXJwbGU6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG53aWR0aDogMTJweDtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTsgfVxyXG5cclxuLnNjcm9sbGJhci1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjNTEyZGE4OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWRlZXAtcHVycGxlIHtcclxuc2Nyb2xsYmFyLWNvbG9yOiAjNTEyZGE4ICNGNUY1RjU7XHJcbn1cclxuXHJcbi5zY3JvbGxiYXItY3lhbjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1O1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxud2lkdGg6IDEycHg7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7IH1cclxuXHJcbi5zY3JvbGxiYXItY3lhbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjMDBiY2Q0OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW4ge1xyXG5zY3JvbGxiYXItY29sb3I6ICMwMGJjZDQgI0Y1RjVGNTtcclxufVxyXG5cclxuLnNjcm9sbGJhci1kdXN0eS1ncmFzczo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1O1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWR1c3R5LWdyYXNzOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiAxMnB4O1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWR1c3R5LWdyYXNzOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KDMzMGRlZywgI2Q0ZmM3OSAwJSwgIzk2ZTZhMSAxMDAlKTtcclxuYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDEyMGRlZywgI2Q0ZmM3OSAwJSwgIzk2ZTZhMSAxMDAlKTsgfVxyXG5cclxuLnNjcm9sbGJhci1yaXBlLW1hbGlua2E6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1yaXBlLW1hbGlua2E6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxud2lkdGg6IDEycHg7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7IH1cclxuXHJcbi5zY3JvbGxiYXItcmlwZS1tYWxpbmthOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KDMzMGRlZywgI2YwOTNmYiAwJSwgI2Y1NTc2YyAxMDAlKTtcclxuYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KDEyMGRlZywgI2YwOTNmYiAwJSwgI2Y1NTc2YyAxMDAlKTsgfVxyXG5cclxuLmJvcmRlcmVkLWRlZXAtcHVycGxlOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcclxuYm9yZGVyOiAxcHggc29saWQgIzUxMmRhODsgfVxyXG5cclxuLmJvcmRlcmVkLWRlZXAtcHVycGxlOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogbm9uZTsgfVxyXG5cclxuLmJvcmRlcmVkLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBub25lO1xyXG5ib3JkZXI6IDFweCBzb2xpZCAjMDBiY2Q0OyB9XHJcblxyXG4uYm9yZGVyZWQtY3lhbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IG5vbmU7IH1cclxuXHJcbi5zcXVhcmU6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50OyB9XHJcblxyXG4uc3F1YXJlOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbmJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDsgfVxyXG5cclxuLnRoaW46Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxud2lkdGg6IDZweDsgfVxyXG5cclxuLmV4YW1wbGUtMSB7XHJcbnBvc2l0aW9uOiByZWxhdGl2ZTtcclxub3ZlcmZsb3cteTogc2Nyb2xsO1xyXG5oZWlnaHQ6IDI1MHB4OyB9XHJcbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](IssueComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-issue',
                templateUrl: './issue.component.html',
                styleUrls: ['./issue.component.scss']
            }]
    }], function () { return [{ type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }, { type: ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_5__["ToastService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class LoginComponent {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
    }
    ngOnInit() {
    }
    onClickSubmit() {
        console.log(this.declared.Email);
        localStorage.setItem("first", this.declared.Email);
        localStorage.setItem("pass", this.declared.Password);
        this.router.navigateByUrl('/loadinga');
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 35, vars: 2, consts: [[1, "b"], ["src", "./assets/NBSZ.png", 2, "width", "80px", "height", "80px", "margin-left", "45%"], [1, "a"], [1, "color-b", "white-text", "text-center", "py-4"], [1, "px-lg-5"], [1, "text-center", 2, "color", "#757575", 3, "ngSubmit"], ["userLogin", "ngForm"], ["href", "", "target", "_blank"], [1, "md-form", "mt-3"], ["type", "email", "name", "Email", "id", "materialSubscriptionFormUsername", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormUsername"], [1, "md-form"], ["type", "password", "name", "Password", "id", "materialSubscriptionFormPasswords", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormPasswords"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", "type", "submit", 1, "z-depth-0", "my-4", "waves-effect"], ["href", ""]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mdb-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mdb-card-header", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Online Requisitions");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "mdb-card-body", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "form", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function LoginComponent_Template_form_ngSubmit_9_listener() { return ctx.onClickSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Please log in to make recquisitions, ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "code");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "easy and reliable.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "No account.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_19_listener($event) { return ctx.declared.Email = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "label", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_23_listener($event) { return ctx.declared.Password = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Sign in");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Forgot Password? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "a", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, "Reset");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Email);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Password);
    } }, directives: [angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardHeaderComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardBodyComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["WavesDirective"]], styles: [".a[_ngcontent-%COMP%] {\n  width: 60%;\n  padding: 0% 15%;\n  margin: 0% 20%;\n}\n\n.color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  background-image: url('books.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxVQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFDRDs7QUFDQTtFQUNDLHlCQUFBO0FBRUQ7O0FBQUE7RUFDQyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUFHRCIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF7XHJcblx0d2lkdGg6IDYwJTtcclxuXHRwYWRkaW5nOiAwJSAxNSU7XHJcblx0bWFyZ2luOiAwJSAyMCU7XHJcbn1cclxuLmNvbG9yLWJ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxufVxyXG4uYntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMCU7XHJcblx0YmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvYm9va3MuanBnJyk7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuXHRiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG5cdGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcblx0b3BhY2l0eTogMC45O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login',
                templateUrl: './login.component.html',
                styleUrls: ['./login.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/password/password.component.ts":
/*!************************************************!*\
  !*** ./src/app/password/password.component.ts ***!
  \************************************************/
/*! exports provided: PasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordComponent", function() { return PasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class PasswordComponent {
    constructor(restApi, router) {
        this.restApi = restApi;
        this.router = router;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.in = [];
    }
    ngOnInit() {
    }
    onClickChange() {
        console.log(this.declared);
        this.restApi.changePassword(this.declared)
            .subscribe(data => console.log("Succeeded, result = " + data), (err) => console.error("Failed! " + err));
    }
}
PasswordComponent.ɵfac = function PasswordComponent_Factory(t) { return new (t || PasswordComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_2__["RestapiService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"])); };
PasswordComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PasswordComponent, selectors: [["app-password"]], decls: 35, vars: 3, consts: [[1, "b"], [1, ""], [1, "a"], [1, "color-b", "white-text", "text-center", "py-4"], [1, "px-lg-5"], [1, "text-center", 2, "color", "#757575", 3, "ngSubmit"], ["userLogin", "ngForm"], [1, "md-form"], ["type", "email", "name", "Email", "id", "materialLoginFormCurrentEmailC", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialLoginFormCurrentEmailC"], ["type", "password", "name", "PasswordC", "id", "materialLoginFormCurrentPassword", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialLoginFormCurrentPassword"], ["type", "password", "id", "materialLoginFormPassword", "name", "PasswordNew", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialPass"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", "type", "submit", 1, "my-4", "waves-effect", "z-depth-0"], ["href", ""], [1, "footer"], [1, "h", "ah"], [1, "h"]], template: function PasswordComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mdb-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mdb-card-header", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mdb-card-body", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "form", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function PasswordComponent_Template_form_ngSubmit_10_listener() { return ctx.onClickChange(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PasswordComponent_Template_input_ngModelChange_13_listener($event) { return ctx.declared.Email = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PasswordComponent_Template_input_ngModelChange_17_listener($event) { return ctx.declared.PasswordC = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "label", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "Current Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PasswordComponent_Template_input_ngModelChange_21_listener($event) { return ctx.declared.PasswordNew = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "New Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Change");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Need help? Contact the ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "a", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "admin");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "p", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "p", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Email);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.PasswordC);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.PasswordNew);
    } }, directives: [angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardHeaderComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardBodyComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["WavesDirective"]], styles: [".a[_ngcontent-%COMP%] {\n  width: 60%;\n  padding: 0% 15%;\n  margin: 0% 20%;\n}\n\n.color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n\n.footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 130%;\n  background-image: url('plain2.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFzc3dvcmQvcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxVQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFDRDs7QUFDQTtFQUNDLHlCQUFBO0FBRUQ7O0FBQUE7RUFDQyxXQUFBO0VBQ0EsYUFBQTtFQUNBLHdCQUFBO0FBR0Q7O0FBREE7RUFDQyxzQkFBQTtBQUlEOztBQUZBO0VBQ0MsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQ0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FBS0Q7O0FBSEE7RUFDQyxZQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBTUQ7O0FBSkE7RUFDQyxZQUFBO0VBQ0EseUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0NBQUE7QUFPRCIsImZpbGUiOiJzcmMvYXBwL3Bhc3N3b3JkL3Bhc3N3b3JkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF7XHJcblx0d2lkdGg6IDYwJTtcclxuXHRwYWRkaW5nOiAwJSAxNSU7XHJcblx0bWFyZ2luOiAwJSAyMCU7XHJcbn1cclxuLmNvbG9yLWJ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxufVxyXG4uZm9vdGVye1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwcHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogc2lsdmVyO1xyXG59XHJcbi5haHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBncmF5O1xyXG59XHJcbi5ie1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTMwJTtcclxuXHRiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9wbGFpbjIuanBnJyk7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuXHRiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG5cdGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcblx0b3BhY2l0eTogMC45O1xyXG59XHJcbi5hcHtcclxuXHRjb2xvcjogYmxhY2s7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogc2lsdmVyO1xyXG5cdGJvcmRlcjoxcHggc29saWQgIzgzMDkwOTtcclxuXHRib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcbi5hcDpob3ZlcntcclxuXHRjb2xvcjogd2hpdGU7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogIzgzMDkwOTtcclxuXHRib3JkZXI6MXB4IHNvbGlkIGJsYWNrO1xyXG5cdGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggYmxhY2s7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PasswordComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-password',
                templateUrl: './password.component.html',
                styleUrls: ['./password.component.scss']
            }]
    }], function () { return [{ type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_2__["RestapiService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/passwordf/passwordf.component.ts":
/*!**************************************************!*\
  !*** ./src/app/passwordf/passwordf.component.ts ***!
  \**************************************************/
/*! exports provided: PasswordfComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordfComponent", function() { return PasswordfComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/__ivy_ngcc__/fesm2015/angular-bootstrap-md.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







class PasswordfComponent {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
    }
    ngOnInit() {
    }
    onClickSubmit() {
        console.log(this.declared.Email);
        localStorage.setItem("first", this.declared.Email);
        localStorage.setItem("pass", this.declared.Password);
        this.router.navigateByUrl('/loadinga');
    }
}
PasswordfComponent.ɵfac = function PasswordfComponent_Factory(t) { return new (t || PasswordfComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
PasswordfComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PasswordfComponent, selectors: [["app-passwordf"]], decls: 34, vars: 2, consts: [[1, "b"], ["src", "./assets/NBSZ.png", 2, "width", "80px", "height", "80px", "margin-left", "45%"], [1, "a"], ["role", "alert", 1, "alert", "alert-danger"], [1, "color-b", "white-text", "text-center", "py-4"], [1, "px-lg-5"], [1, "text-center", 2, "color", "#757575", 3, "ngSubmit"], ["userLogin", "ngForm"], [1, "md-form", "mt-3"], ["type", "email", "name", "Email", "id", "materialSubscriptionFormUsername", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormUsername"], [1, "md-form"], ["type", "password", "name", "Password", "id", "materialSubscriptionFormPasswords", "mdbInput", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["for", "materialSubscriptionFormPasswords"], ["mdbBtn", "", "color", "info", "outline", "true", "rounded", "true", "block", "true", "mdbWavesEffect", "", "type", "submit", 1, "z-depth-0", "my-4", "waves-effect"], ["href", ""]], template: function PasswordfComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Log in failure!!!!\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mdb-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mdb-card-header", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Log in");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "mdb-card-body", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "form", 6, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngSubmit", function PasswordfComponent_Template_form_ngSubmit_12_listener() { return ctx.onClickSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Please log in to make recquisitions, ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "code");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "easy and reliable.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, " Wrong password or username.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PasswordfComponent_Template_input_ngModelChange_21_listener($event) { return ctx.declared.Email = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "label", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function PasswordfComponent_Template_input_ngModelChange_25_listener($event) { return ctx.declared.Password = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Sign in");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, "Forgot Password? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "a", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Reset");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Email);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.declared.Password);
    } }, directives: [angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardHeaderComponent"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbCardBodyComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵangular_packages_forms_forms_y"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbInput"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["MdbBtnDirective"], angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_4__["WavesDirective"]], styles: [".a[_ngcontent-%COMP%] {\n  width: 60%;\n  padding: 0% 15%;\n  margin: 0% 20%;\n}\n\n.color-b[_ngcontent-%COMP%] {\n  background-color: #830909;\n}\n\n.ab[_ngcontent-%COMP%] {\n  width: 60%;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  background-image: url('books.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFzc3dvcmRmL3Bhc3N3b3JkZi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLFVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUNEOztBQUNBO0VBQ0MseUJBQUE7QUFFRDs7QUFBQTtFQUNDLFVBQUE7QUFHRDs7QUFEQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUlEIiwiZmlsZSI6InNyYy9hcHAvcGFzc3dvcmRmL3Bhc3N3b3JkZi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5he1xyXG5cdHdpZHRoOiA2MCU7XHJcblx0cGFkZGluZzogMCUgMTUlO1xyXG5cdG1hcmdpbjogMCUgMjAlO1xyXG59XHJcbi5jb2xvci1ie1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICM4MzA5MDk7XHJcbn1cclxuLmFie1xyXG5cdHdpZHRoOiA2MCU7XHJcbn0gXHJcbi5ie1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGhlaWdodDogMTAwJTtcclxuXHRiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9ib29rcy5qcGcnKTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG5cdGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcblx0YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuXHRvcGFjaXR5OiAwLjk7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PasswordfComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-passwordf',
                templateUrl: './passwordf.component.html',
                styleUrls: ['./passwordf.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/pending/pending.component.ts":
/*!**********************************************!*\
  !*** ./src/app/pending/pending.component.ts ***!
  \**********************************************/
/*! exports provided: PendingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PendingComponent", function() { return PendingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");







function PendingComponent_div_22_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "table", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Description");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Quantity");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Comment");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](25, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "code");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "-----end of request-------");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const data_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Department: ", data_r1.DptTo, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Date: ", data_r1.Date, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Authorisor:", data_r1.AuthorisedBy, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Description);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Quantity);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Comment);
} }
class PendingComponent {
    constructor(restApi, router) {
        this.restApi = restApi;
        this.router = router;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.in = [];
        this.sessionValue = "";
        this.local = "";
        this.localValue = "";
        this.Em = "";
    }
    ngOnInit() {
        this.validatingForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            modalFormAvatarPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required)
        });
        this.sessionValue = localStorage.getItem("first");
        this.local = sessionStorage.getItem("second");
        console.log("here in pending DPT:  " + this.local);
        this.loadData(this.local);
    }
    get modalFormAvatarPassword() {
        return this.validatingForm.get('modalFormAvatarPassword');
    }
    loadData(value) {
        console.log("Value chifango " + value);
        return this.restApi.getPendingData(this.sessionValue)
            .subscribe(data => this.in = data);
    }
    goTOInternal() {
        this.router.navigateByUrl('/internal');
    }
    goToP() {
        this.router.navigateByUrl('/password');
    }
    goToPending() {
        this.go();
        this.router.navigateByUrl('/pending');
    }
    goToIssue() {
        this.go();
        this.router.navigateByUrl('/issue');
    }
    go() {
        sessionStorage.setItem("second", this.Em);
        this.localValue = sessionStorage.getItem("second");
        console.log("Department" + this.Em);
        console.log("Session Dot " + this.localValue);
    }
}
PendingComponent.ɵfac = function PendingComponent_Factory(t) { return new (t || PendingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"])); };
PendingComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PendingComponent, selectors: [["app-pending"]], decls: 40, vars: 3, consts: [[1, "b"], [1, "", 2, "width", "100%", "box-shadow", "15px 15px 15px silver", "color", "#830909"], ["id", "movetxt"], [1, "h"], [1, "maindiv"], [1, "left"], [1, "ap", 3, "click"], [1, "center"], [1, "card-body"], [1, "card", "richy", "example-1", "scrollbar-ripe-malinka", "bordered-deep-purple", "thin"], [4, "ngFor", "ngForOf"], [1, "right"], [1, "footer"], [1, "h", "ah"], [1, "table", "table-striped", "w-auto"], [1, "ap"]], template: function PendingComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Life is in the Blood. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h4", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PendingComponent_Template_button_click_12_listener() { return ctx.goToP(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Pending Recquisitions");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "code");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "Note that these are yours requsitions note yet approved, call the responsible person to approve.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](22, PendingComponent_div_22_Template, 29, 6, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Make a request");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PendingComponent_Template_button_click_26_listener() { return ctx.goTOInternal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Internal Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PendingComponent_Template_button_click_29_listener() { return ctx.goToPending(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Pending .");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](31, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PendingComponent_Template_button_click_32_listener() { return ctx.goToIssue(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "Issue out");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Eplore the World | ", ctx.sessionValue, "| ", ctx.declared.Email, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.in);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"]], styles: [".footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 120%;\n  background-image: url('plain1.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n\n.spacer[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n}\n\n#form[_ngcontent-%COMP%] {\n  background-color: white;\n  border: 1px solid green;\n  text-align: center;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%] {\n  color: #00134d;\n  background-color: white;\n  border: 1px solid green;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%]:hover {\n  background-color: green;\n  color: white;\n}\n\n.slidera[_ngcontent-%COMP%] {\n  height: 500px;\n}\n\n.head[_ngcontent-%COMP%] {\n  margin: 5%;\n}\n\n.head1[_ngcontent-%COMP%] {\n  background-color: #f5f5ef;\n  height: 70px;\n  width: 100%;\n}\n\n.main[_ngcontent-%COMP%] {\n  height: auto;\n  width: 100%;\n  background-color: transparent;\n  background-color: #f5f5ef;\n}\n\n.first[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  border-radius: 5px;\n  margin: 2% 2%;\n  padding: 2%;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.second[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 1%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.third[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 2%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s1[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s2[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.first[_ngcontent-%COMP%]:hover, .first1[_ngcontent-%COMP%]:hover, .second[_ngcontent-%COMP%]:hover, .second1[_ngcontent-%COMP%]:hover, .third[_ngcontent-%COMP%]:hover {\n  border: 2px solid #006699;\n  box-shadow: 15px 15px 15px #006699;\n  background-color: white;\n  color: #00134d;\n}\n\n.btna[_ngcontent-%COMP%] {\n  margin: 2% 2%;\n  color: #00134d;\n  background-color: white;\n  border: 1px solid #00134d;\n  border-radius: 2px;\n}\n\n.btna[_ngcontent-%COMP%]:hover {\n  margin: 3% 3%;\n  color: green;\n  background-color: white;\n  border: 1px solid green;\n  border-radius: 2px;\n}\n\n.footerr[_ngcontent-%COMP%] {\n  height: 200px;\n  width: 100%;\n}\n\n#movetxt[_ngcontent-%COMP%] {\n  animation-duration: 20s;\n  animation-name: slidein;\n  animation-iteration-count: infinite;\n}\n\n@keyframes slidein {\n  from {\n    margin-left: 100%;\n    width: 300%;\n  }\n  to {\n    margin-left: 0%;\n    width: 100%;\n  }\n}\n\n.maindiv[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 450px;\n  background-color: transparent;\n  padding: 1%;\n}\n\n.left[_ngcontent-%COMP%] {\n  width: 20%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 1% 0%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.richy[_ngcontent-%COMP%] {\n  padding: 4%;\n}\n\n.center[_ngcontent-%COMP%] {\n  width: 53%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 0%;\n  box-shadow: 5px 5px 5px 5px;\n}\n\n.right[_ngcontent-%COMP%] {\n  width: 16%;\n  height: auto;\n  background-color: transparent;\n  float: right;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #512da8;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%] {\n  scrollbar-color: #512da8 #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #00bcd4;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%] {\n  scrollbar-color: #00bcd4 #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #d4fc79 0%, #96e6a1 100%);\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #f093fb 0%, #f5576c 100%);\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #512da8;\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #00bcd4;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  border-radius: 0 !important;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 0 !important;\n}\n\n.thin[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n\n.example-1[_ngcontent-%COMP%] {\n  position: relative;\n  overflow-y: scroll;\n  height: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGVuZGluZy9wZW5kaW5nLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsV0FBQTtFQUNBLGFBQUE7RUFDQSx3QkFBQTtBQUNEOztBQUNBO0VBQ0Msc0JBQUE7QUFFRDs7QUFBQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUdEOztBQURBO0VBQ0MsWUFBQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUlEOztBQUZBO0VBQ0MsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0FBS0Q7O0FBSEE7RUFDQyxjQUFBO0FBTUQ7O0FBSEE7RUFDQyx1QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLDhCQUFBO0FBTUQ7O0FBSkE7RUFDQyxjQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7QUFPRDs7QUFMQTtFQUNDLHVCQUFBO0VBQ0EsWUFBQTtBQVFEOztBQU5BO0VBQ0MsYUFBQTtBQVNEOztBQVBBO0VBQ0MsVUFBQTtBQVVEOztBQVJBO0VBQ0MseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQVdEOztBQVRBO0VBQ0MsWUFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLHlCQUFBO0FBWUQ7O0FBVkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBYUQ7O0FBVkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBYUQ7O0FBVEE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBWUQ7O0FBVEE7RUFDQyxrQkFBQTtBQVlEOztBQVZBO0VBQ0Msa0JBQUE7QUFhRDs7QUFYQTtFQUNDLHNCQUFBO0FBY0Q7O0FBWEE7RUFDRSx5QkFBQTtFQUNELGtDQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FBY0Q7O0FBWkE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQWVEOztBQVpDO0VBQ0MsYUFBQTtFQUNELFlBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFlRDs7QUFiQztFQUNHLGFBQUE7RUFDQSxXQUFBO0FBZ0JKOztBQVpBO0VBQ0MsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1DQUFBO0FBZUQ7O0FBYkE7RUFDQztJQUNDLGlCQUFBO0lBQ0EsV0FBQTtFQWdCQTtFQWREO0lBQ0MsZUFBQTtJQUNBLFdBQUE7RUFnQkE7QUFDRjs7QUFkQTtFQUNDLFdBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0FBZ0JEOztBQWRBO0VBQ0MsVUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFpQkQ7O0FBWkE7RUFDQyxXQUFBO0FBZUQ7O0FBYkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0FBZ0JEOztBQWRBO0VBQ0MsVUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFpQkQ7O0FBZEE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFpQkE7O0FBZkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUFrQkE7O0FBaEJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0FBbUJBOztBQWpCQTtFQUNBLGdDQUFBO0FBb0JBOztBQWpCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQW9CQTs7QUFsQkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUFxQkE7O0FBbkJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0FBc0JBOztBQXBCQTtFQUNBLGdDQUFBO0FBdUJBOztBQXBCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQXVCQTs7QUFyQkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUF3QkE7O0FBdEJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUVBLG1FQUFBO0FBeUJBOztBQXZCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQTBCQTs7QUF4QkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUEyQkE7O0FBekJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUVBLG1FQUFBO0FBNEJBOztBQTFCQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7QUE2QkE7O0FBM0JBO0VBQ0Esd0JBQUE7QUE4QkE7O0FBNUJBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQStCQTs7QUE3QkE7RUFDQSx3QkFBQTtBQWdDQTs7QUE5QkE7RUFDQSwyQkFBQTtBQWlDQTs7QUEvQkE7RUFDQSwyQkFBQTtBQWtDQTs7QUFoQ0E7RUFDQSxVQUFBO0FBbUNBOztBQWpDQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FBb0NBIiwiZmlsZSI6InNyYy9hcHAvcGVuZGluZy9wZW5kaW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvb3RlcntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHNpbHZlcjtcclxufVxyXG4uYWh7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxufVxyXG4uYntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEyMCU7XHJcblx0YmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvcGxhaW4xLmpwZycpO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcblx0YmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuXHRiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG5cdG9wYWNpdHk6IDAuOTtcclxufVxyXG4uYXB7XHJcblx0Y29sb3I6IGJsYWNrO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHNpbHZlcjtcclxuXHRib3JkZXI6MXB4IHNvbGlkICM4MzA5MDk7XHJcblx0Ym9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG4uYXA6aG92ZXJ7XHJcblx0Y29sb3I6IHdoaXRlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICM4MzA5MDk7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCBibGFjaztcclxuXHRib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cdGJveC1zaGFkb3c6IDEwcHggMTBweCAxMHB4IGJsYWNrO1xyXG59XHJcbi5zcGFjZXJ7XHJcblx0ZmxleDoxIDEgYXV0bztcclxufVxyXG5cclxuI2Zvcm17XHJcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuXHRib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbn1cclxuLmJ0bmFhe1xyXG5cdGNvbG9yOiByZ2IoMCwxOSw3Nyk7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcblx0Ym9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuXHRib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xyXG59XHJcbi5idG5hYTpob3ZlcntcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcclxuXHRjb2xvcjogd2hpdGU7XHJcbn1cclxuLnNsaWRlcmF7XHJcblx0aGVpZ2h0OiA1MDBweDtcclxufVxyXG4uaGVhZHtcclxuXHRtYXJnaW46IDUlO1xyXG59XHJcbi5oZWFkMXs7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwyNDUsMjM5KTtcclxuXHRoZWlnaHQ6IDcwcHg7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuLm1haW57XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHJnYigyNDUsMjQ1LDIzOSk7XHJcbn1cclxuLmZpcnN0e1xyXG5cdHdpZHRoOiAzMCU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRtYXJnaW46IDIlIDIlO1xyXG5cdHBhZGRpbmc6IDIlO1xyXG5cdGJvcmRlcjoxcHggc29saWQgcmdiKDAsMTksNzcpO1xyXG5cdGJveC1zaGFkb3c6IDEwcHggMTBweCAxMHB4IHJnYigwLDE5LDc3KTtcclxufVxyXG5cclxuLnNlY29uZHtcclxuXHR3aWR0aDogMzAlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRtYXJnaW46IDIlIDElO1xyXG5cdHBhZGRpbmc6IDIlO1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRib3JkZXI6MXB4IHNvbGlkIHJnYigwLDE5LDc3KTtcclxuXHRib3gtc2hhZG93OiAxMHB4IDEwcHggMTBweCByZ2IoMCwxOSw3Nyk7XHJcblxyXG59XHJcblxyXG4udGhpcmR7XHJcblx0d2lkdGg6IDMwJTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luOiAyJSAyJTtcclxuXHRwYWRkaW5nOiAyJTtcclxuXHRib3JkZXItcmFkaXVzOiA1cHg7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCByZ2IoMCwxOSw3Nyk7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggcmdiKDAsMTksNzcpO1xyXG59XHJcblxyXG4uaHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLnMxe1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4uczJ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxufVxyXG5cclxuLmZpcnN0OmhvdmVyLC5maXJzdDE6aG92ZXIsIC5zZWNvbmQ6aG92ZXIsLnNlY29uZDE6aG92ZXIsIC50aGlyZDpob3ZlciB7XHJcblx0XHRib3JkZXI6MnB4IHNvbGlkIHJnYigwLCAxMDIsIDE1Myk7XHJcblx0Ym94LXNoYWRvdzogMTVweCAxNXB4IDE1cHggcmdiKDAsIDEwMiwgMTUzKTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRjb2xvcjogcmdiKDAsMTksNzcpO1xyXG59XHJcbi5idG5he1xyXG5cdG1hcmdpbjogMiUgMiU7XHJcblx0Y29sb3I6IHJnYigwLDE5LDc3KTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCByZ2IoMCwxOSw3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogMnB4O1xyXG59XHJcblxyXG4gLmJ0bmE6aG92ZXJ7XHJcbiBcdG1hcmdpbjogMyUgMyU7XHJcblx0Y29sb3I6IGdyZWVuO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIGdyZWVuO1xyXG5cdGJvcmRlci1yYWRpdXM6IDJweDtcclxuIH1cclxuIC5mb290ZXJye1xyXG4gXHQgXHRoZWlnaHQ6IDIwMHB4O1xyXG4gXHQgXHR3aWR0aDogMTAwJTtcclxuIH1cclxuXHJcbiBcclxuI21vdmV0eHR7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOjIwcztcclxuXHRhbmltYXRpb24tbmFtZTogc2xpZGVpbjtcclxuXHRhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG59XHJcbkBrZXlmcmFtZXMgc2xpZGVpbntcclxuXHRmcm9te1xyXG5cdFx0bWFyZ2luLWxlZnQ6IDEwMCU7XHJcblx0XHR3aWR0aDogMzAwJTtcclxuXHR9XHJcblx0dG97XHJcblx0XHRtYXJnaW4tbGVmdDogMCU7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuLm1haW5kaXZ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA0NTBweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRwYWRkaW5nOiAxJTtcclxufVxyXG4ubGVmdHtcclxuXHR3aWR0aDogMjAlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRtYXJnaW46IDElIDAlO1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIHJnYigwLCA1MSwgNzcpO1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRwYWRkaW5nOiAxJTtcclxuXHRcclxuXHJcblxyXG59XHJcbi5yaWNoeXtcclxuXHRwYWRkaW5nOiA0JTtcclxufVxyXG4uY2VudGVye1xyXG5cdHdpZHRoOiA1MyU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdG1hcmdpbjogMiU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgcmdiKDAsIDUxLCA3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdHBhZGRpbmc6MCU7XHJcblx0Ym94LXNoYWRvdzogNXB4IDVweCA1cHggNXB4IDtcclxufVxyXG4ucmlnaHR7XHJcblx0d2lkdGg6IDE2JTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IHJpZ2h0O1xyXG5cdG1hcmdpbjogMiU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgcmdiKDAsIDUxLCA3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdHBhZGRpbmc6IDElO1xyXG5cclxufVxyXG4uc2Nyb2xsYmFyLWRlZXAtcHVycGxlOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7IH1cclxuXHJcbi5zY3JvbGxiYXItZGVlcC1wdXJwbGU6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxud2lkdGg6IDEycHg7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7IH1cclxuXHJcbi5zY3JvbGxiYXItZGVlcC1wdXJwbGU6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogIzUxMmRhODsgfVxyXG5cclxuLnNjcm9sbGJhci1kZWVwLXB1cnBsZSB7XHJcbnNjcm9sbGJhci1jb2xvcjogIzUxMmRhOCAjRjVGNUY1O1xyXG59XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1jeWFuOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiAxMnB4O1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogIzAwYmNkNDsgfVxyXG5cclxuLnNjcm9sbGJhci1jeWFuIHtcclxuc2Nyb2xsYmFyLWNvbG9yOiAjMDBiY2Q0ICNGNUY1RjU7XHJcbn1cclxuXHJcbi5zY3JvbGxiYXItZHVzdHktZ3Jhc3M6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1kdXN0eS1ncmFzczo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG53aWR0aDogMTJweDtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTsgfVxyXG5cclxuLnNjcm9sbGJhci1kdXN0eS1ncmFzczo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWltYWdlOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgzMzBkZWcsICNkNGZjNzkgMCUsICM5NmU2YTEgMTAwJSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgxMjBkZWcsICNkNGZjNzkgMCUsICM5NmU2YTEgMTAwJSk7IH1cclxuXHJcbi5zY3JvbGxiYXItcmlwZS1tYWxpbmthOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7IH1cclxuXHJcbi5zY3JvbGxiYXItcmlwZS1tYWxpbmthOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiAxMnB4O1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1OyB9XHJcblxyXG4uc2Nyb2xsYmFyLXJpcGUtbWFsaW5rYTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWltYWdlOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgzMzBkZWcsICNmMDkzZmIgMCUsICNmNTU3NmMgMTAwJSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgxMjBkZWcsICNmMDkzZmIgMCUsICNmNTU3NmMgMTAwJSk7IH1cclxuXHJcbi5ib3JkZXJlZC1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IG5vbmU7XHJcbmJvcmRlcjogMXB4IHNvbGlkICM1MTJkYTg7IH1cclxuXHJcbi5ib3JkZXJlZC1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IG5vbmU7IH1cclxuXHJcbi5ib3JkZXJlZC1jeWFuOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcclxuYm9yZGVyOiAxcHggc29saWQgIzAwYmNkNDsgfVxyXG5cclxuLmJvcmRlcmVkLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBub25lOyB9XHJcblxyXG4uc3F1YXJlOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbmJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDsgfVxyXG5cclxuLnNxdWFyZTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7IH1cclxuXHJcbi50aGluOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiA2cHg7IH1cclxuXHJcbi5leGFtcGxlLTEge1xyXG5wb3NpdGlvbjogcmVsYXRpdmU7XHJcbm92ZXJmbG93LXk6IHNjcm9sbDtcclxuaGVpZ2h0OiAyNTBweDsgfVxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PendingComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-pending',
                templateUrl: './pending.component.html',
                styleUrls: ['./pending.component.scss']
            }]
    }], function () { return [{ type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/please/please.component.ts":
/*!********************************************!*\
  !*** ./src/app/please/please.component.ts ***!
  \********************************************/
/*! exports provided: PleaseComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PleaseComponent", function() { return PleaseComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class PleaseComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        setTimeout(() => {
            this.router.navigateByUrl('/internal-items');
        }, 5000);
    }
}
PleaseComponent.ɵfac = function PleaseComponent_Factory(t) { return new (t || PleaseComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
PleaseComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PleaseComponent, selectors: [["app-please"]], decls: 5, vars: 0, consts: [[1, "h"], ["src", "./assets/load.gif", 2, "width", "300px", "height", "300px", "margin-left", "40%"]], template: function PleaseComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "wait your page is being ready");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 1);
    } }, styles: [".h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGxlYXNlL3BsZWFzZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNDLGtCQUFBO0FBQ0QiLCJmaWxlIjoic3JjL2FwcC9wbGVhc2UvcGxlYXNlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmh7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PleaseComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-please',
                templateUrl: './please.component.html',
                styleUrls: ['./please.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/please1/please1.component.ts":
/*!**********************************************!*\
  !*** ./src/app/please1/please1.component.ts ***!
  \**********************************************/
/*! exports provided: Please1Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Please1Component", function() { return Please1Component; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");





class Please1Component {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
        this.sessionEmail = "";
        this.sessionPass = "";
    }
    ngOnInit() {
        this.sessionEmail = localStorage.getItem("first");
        this.sessionPass = localStorage.getItem("pass");
        this.declared.Email = this.sessionEmail;
        this.declared.Password = this.sessionPass;
        console.log(this.declared);
        setTimeout(() => {
            this.restApi.sign(this.declared)
                .subscribe(data => this.router.navigateByUrl('/' + data), (err) => console.error("Failed! " + err));
        }, 5000);
    }
}
Please1Component.ɵfac = function Please1Component_Factory(t) { return new (t || Please1Component)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
Please1Component.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: Please1Component, selectors: [["app-please1"]], decls: 5, vars: 0, consts: [[1, "h"], ["src", "./assets/load.gif", 2, "width", "300px", "height", "300px", "margin-left", "40%"]], template: function Please1Component_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Verifyng your credentials, Please wait.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 1);
    } }, styles: [".h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGxlYXNlMS9wbGVhc2UxLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Msa0JBQUE7QUFDRCIsImZpbGUiOiJzcmMvYXBwL3BsZWFzZTEvcGxlYXNlMS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oe1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Please1Component, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-please1',
                templateUrl: './please1.component.html',
                styleUrls: ['./please1.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/please2/please2.component.ts":
/*!**********************************************!*\
  !*** ./src/app/please2/please2.component.ts ***!
  \**********************************************/
/*! exports provided: Please2Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Please2Component", function() { return Please2Component; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");





class Please2Component {
    constructor(router, restApi) {
        this.router = router;
        this.restApi = restApi;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.push = [];
        this.sessionEmail = "";
        this.sessionPass = "";
        this.checkout = "";
    }
    ngOnInit() {
        this.sessionEmail = localStorage.getItem("first");
        this.sessionPass = localStorage.getItem("pass");
        this.checkout = sessionStorage.getItem("checkout");
        this.declared.Email = this.sessionEmail;
        this.declared.Password = this.sessionPass;
        console.log(this.declared);
        setTimeout(() => {
            return this.restApi.getIs(this.checkout)
                .subscribe(data => this.router.navigateByUrl('/' + data));
        }, 5000);
    }
}
Please2Component.ɵfac = function Please2Component_Factory(t) { return new (t || Please2Component)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"])); };
Please2Component.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: Please2Component, selectors: [["app-please2"]], decls: 5, vars: 0, consts: [[1, "h"], ["src", "./assets/load.gif", 2, "width", "300px", "height", "300px", "margin-left", "40%"]], template: function Please2Component_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Checking the order, Please wait.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "img", 1);
    } }, styles: [".h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGxlYXNlMi9wbGVhc2UyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Msa0JBQUE7QUFDRCIsImZpbGUiOiJzcmMvYXBwL3BsZWFzZTIvcGxlYXNlMi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oe1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Please2Component, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-please2',
                templateUrl: './please2.component.html',
                styleUrls: ['./please2.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_3__["RestapiService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/request/request.component.ts":
/*!**********************************************!*\
  !*** ./src/app/request/request.component.ts ***!
  \**********************************************/
/*! exports provided: RequestComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestComponent", function() { return RequestComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/data */ "./src/app/data/data.ts");
/* harmony import */ var _data_restapi_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data/restapi.service */ "./src/app/data/restapi.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");






function RequestComponent_div_20_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "table", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Description");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Quantity");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Comment");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RequestComponent_div_20_Template_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3); const data_r1 = ctx.$implicit; const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r2.approve(data_r1.ID_Key); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Approve");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "code");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "-----end of request-------");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "hr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](30, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const data_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Requestor:", data_r1.RequestedBy, " (", data_r1.DptFrom, ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Department To: ", data_r1.DptTo, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Date: ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](7, 8, data_r1.Date, "dd-MM-yyyy"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Description);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Quantity);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](data_r1.Comment);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", data_r1.ID_Key);
} }
class RequestComponent {
    constructor(restApi, router) {
        this.restApi = restApi;
        this.router = router;
        this.declared = new _data_data__WEBPACK_IMPORTED_MODULE_1__["declaredData"]();
        this.in = [];
        this.sessionValue = "";
        this.localValue = "";
    }
    ngOnInit() {
        this.sessionValue = localStorage.getItem("first");
        if (this.sessionValue == null) {
            this.router.navigateByUrl('/login');
        }
        else {
            this.loadData();
            this.Email();
        }
    }
    go() {
        sessionStorage.setItem("second", this.Em);
        this.localValue = sessionStorage.getItem("second");
        console.log("Department" + this.Em);
        console.log("Session Dot " + this.localValue);
    }
    loadData() {
        return this.restApi.getData(this.sessionValue)
            .subscribe(data => this.in = data);
    }
    Email() {
        return this.restApi.getDpt(this.sessionValue)
            .subscribe(data => this.Em = data);
    }
    goTOInternal() {
        this.router.navigateByUrl('/internal');
    }
    goToP() {
        this.router.navigateByUrl('/password');
    }
    goToPending() {
        this.go();
        this.router.navigateByUrl('/pending');
    }
    goToIssue() {
        this.go();
        this.router.navigateByUrl('/issue');
    }
    approve(key) {
        return this.restApi.getAp(key)
            .subscribe(data => this.richy = data);
        console.log(key);
    }
}
RequestComponent.ɵfac = function RequestComponent_Factory(t) { return new (t || RequestComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_restapi_service__WEBPACK_IMPORTED_MODULE_2__["RestapiService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"])); };
RequestComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: RequestComponent, selectors: [["app-request"]], decls: 38, vars: 3, consts: [[1, "b"], [1, "", 2, "width", "100%", "box-shadow", "15px 15px 15px silver", "color", "#830909"], ["id", "movetxt"], [1, "h"], [1, "maindiv"], [1, "left"], [1, "ap", 3, "click"], [1, "center"], [1, "card-body"], [1, "card", "richy", "example-1", "scrollbar-ripe-malinka", "bordered-deep-purple", "thin"], [4, "ngFor", "ngForOf"], [1, "right"], [1, "footer"], [1, "h", "ah"], [1, "table", "table-striped", "w-auto"], [1, "ap", 3, "value", "click"]], template: function RequestComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Life is in the Blood. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h4", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RequestComponent_Template_button_click_12_listener() { return ctx.goToP(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Approve Recquisitions");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](20, RequestComponent_div_20_Template, 31, 11, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Make a request");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RequestComponent_Template_button_click_24_listener() { return ctx.goTOInternal(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Internal Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RequestComponent_Template_button_click_27_listener() { return ctx.goToPending(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Pending .");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function RequestComponent_Template_button_click_30_listener() { return ctx.goToIssue(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](31, "Issue out");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "@2020");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "let's go digital");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("Eplore the World | ", ctx.sessionValue, "| ", ctx.declared.Email, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.in);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]], styles: [".footer[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100px;\n  background-color: silver;\n}\n\n.ah[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.b[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 120%;\n  background-image: url('plain1.jpg');\n  height: auto;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  opacity: 0.9;\n}\n\n.ap[_ngcontent-%COMP%] {\n  color: black;\n  background-color: silver;\n  border: 1px solid #830909;\n  border-radius: 10px;\n}\n\n.ap[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #830909;\n  border: 1px solid black;\n  border-radius: 10px;\n  box-shadow: 10px 10px 10px black;\n}\n\n.spacer[_ngcontent-%COMP%] {\n  flex: 1 1 auto;\n}\n\n#form[_ngcontent-%COMP%] {\n  background-color: white;\n  border: 1px solid green;\n  text-align: center;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%] {\n  color: #00134d;\n  background-color: white;\n  border: 1px solid green;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.btnaa[_ngcontent-%COMP%]:hover {\n  background-color: green;\n  color: white;\n}\n\n.slidera[_ngcontent-%COMP%] {\n  height: 500px;\n}\n\n.head[_ngcontent-%COMP%] {\n  margin: 5%;\n}\n\n.head1[_ngcontent-%COMP%] {\n  background-color: #f5f5ef;\n  height: 70px;\n  width: 100%;\n}\n\n.main[_ngcontent-%COMP%] {\n  height: auto;\n  width: 100%;\n  background-color: transparent;\n  background-color: #f5f5ef;\n}\n\n.first[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  border-radius: 5px;\n  margin: 2% 2%;\n  padding: 2%;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.second[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 1%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.third[_ngcontent-%COMP%] {\n  width: 30%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2% 2%;\n  padding: 2%;\n  border-radius: 5px;\n  border: 1px solid #00134d;\n  box-shadow: 10px 10px 10px #00134d;\n}\n\n.h[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s1[_ngcontent-%COMP%] {\n  text-align: center;\n}\n\n.s2[_ngcontent-%COMP%] {\n  background-color: gray;\n}\n\n.first[_ngcontent-%COMP%]:hover, .first1[_ngcontent-%COMP%]:hover, .second[_ngcontent-%COMP%]:hover, .second1[_ngcontent-%COMP%]:hover, .third[_ngcontent-%COMP%]:hover {\n  border: 2px solid #006699;\n  box-shadow: 15px 15px 15px #006699;\n  background-color: white;\n  color: #00134d;\n}\n\n.btna[_ngcontent-%COMP%] {\n  margin: 2% 2%;\n  color: #00134d;\n  background-color: white;\n  border: 1px solid #00134d;\n  border-radius: 2px;\n}\n\n.btna[_ngcontent-%COMP%]:hover {\n  margin: 3% 3%;\n  color: green;\n  background-color: white;\n  border: 1px solid green;\n  border-radius: 2px;\n}\n\n.footerr[_ngcontent-%COMP%] {\n  height: 200px;\n  width: 100%;\n}\n\n#movetxt[_ngcontent-%COMP%] {\n  animation-duration: 20s;\n  animation-name: slidein;\n  animation-iteration-count: infinite;\n}\n\n@keyframes slidein {\n  from {\n    margin-left: 100%;\n    width: 300%;\n  }\n  to {\n    margin-left: 0%;\n    width: 100%;\n  }\n}\n\n.maindiv[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 400px;\n  background-color: transparent;\n  padding: 1%;\n}\n\n.left[_ngcontent-%COMP%] {\n  width: 16%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 1% 0%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.richy[_ngcontent-%COMP%] {\n  padding: 4%;\n}\n\n.center[_ngcontent-%COMP%] {\n  width: 53%;\n  height: auto;\n  background-color: transparent;\n  float: left;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 0%;\n  box-shadow: 5px 5px 5px 5px;\n}\n\n.right[_ngcontent-%COMP%] {\n  width: 20%;\n  height: auto;\n  background-color: transparent;\n  float: right;\n  margin: 2%;\n  border: 1px solid #00334d;\n  border-radius: 5px;\n  padding: 1%;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #512da8;\n}\n\n.scrollbar-deep-purple[_ngcontent-%COMP%] {\n  scrollbar-color: #512da8 #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #00bcd4;\n}\n\n.scrollbar-cyan[_ngcontent-%COMP%] {\n  scrollbar-color: #00bcd4 #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-dusty-grass[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #d4fc79 0%, #96e6a1 100%);\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-color: #F5F5F5;\n  border-radius: 10px;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 12px;\n  background-color: #F5F5F5;\n}\n\n.scrollbar-ripe-malinka[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 10px;\n  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);\n  background-image: linear-gradient(120deg, #f093fb 0%, #f5576c 100%);\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #512da8;\n}\n\n.bordered-deep-purple[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  -webkit-box-shadow: none;\n  border: 1px solid #00bcd4;\n}\n\n.bordered-cyan[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  -webkit-box-shadow: none;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-track {\n  border-radius: 0 !important;\n}\n\n.square[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  border-radius: 0 !important;\n}\n\n.thin[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n\n.example-1[_ngcontent-%COMP%] {\n  position: relative;\n  overflow-y: scroll;\n  height: 250px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVxdWVzdC9yZXF1ZXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsV0FBQTtFQUNBLGFBQUE7RUFDQSx3QkFBQTtBQUNEOztBQUNBO0VBQ0Msc0JBQUE7QUFFRDs7QUFBQTtFQUNDLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQUdEOztBQURBO0VBQ0MsWUFBQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUlEOztBQUZBO0VBQ0MsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0FBS0Q7O0FBSEE7RUFDQyxjQUFBO0FBTUQ7O0FBSEE7RUFDQyx1QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLDhCQUFBO0FBTUQ7O0FBSkE7RUFDQyxjQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7QUFPRDs7QUFMQTtFQUNDLHVCQUFBO0VBQ0EsWUFBQTtBQVFEOztBQU5BO0VBQ0MsYUFBQTtBQVNEOztBQVBBO0VBQ0MsVUFBQTtBQVVEOztBQVJBO0VBQ0MseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQVdEOztBQVRBO0VBQ0MsWUFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLHlCQUFBO0FBWUQ7O0FBVkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBYUQ7O0FBVkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBYUQ7O0FBVEE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBWUQ7O0FBVEE7RUFDQyxrQkFBQTtBQVlEOztBQVZBO0VBQ0Msa0JBQUE7QUFhRDs7QUFYQTtFQUNDLHNCQUFBO0FBY0Q7O0FBWEE7RUFDRSx5QkFBQTtFQUNELGtDQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FBY0Q7O0FBWkE7RUFDQyxhQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQWVEOztBQVpDO0VBQ0MsYUFBQTtFQUNELFlBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFlRDs7QUFiQztFQUNHLGFBQUE7RUFDQSxXQUFBO0FBZ0JKOztBQVpBO0VBQ0MsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1DQUFBO0FBZUQ7O0FBYkE7RUFDQztJQUNDLGlCQUFBO0lBQ0EsV0FBQTtFQWdCQTtFQWREO0lBQ0MsZUFBQTtJQUNBLFdBQUE7RUFnQkE7QUFDRjs7QUFkQTtFQUNDLFdBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxXQUFBO0FBZ0JEOztBQWRBO0VBQ0MsVUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFpQkQ7O0FBWkE7RUFDQyxXQUFBO0FBZUQ7O0FBYkE7RUFDQyxVQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0FBZ0JEOztBQWRBO0VBQ0MsVUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFpQkQ7O0FBZEE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFpQkE7O0FBZkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUFrQkE7O0FBaEJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0FBbUJBOztBQWpCQTtFQUNBLGdDQUFBO0FBb0JBOztBQWpCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQW9CQTs7QUFsQkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUFxQkE7O0FBbkJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLHlCQUFBO0FBc0JBOztBQXBCQTtFQUNBLGdDQUFBO0FBdUJBOztBQXBCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQXVCQTs7QUFyQkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUF3QkE7O0FBdEJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUVBLG1FQUFBO0FBeUJBOztBQXZCQTtFQUNBLG9EQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQTBCQTs7QUF4QkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7QUEyQkE7O0FBekJBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUVBLG1FQUFBO0FBNEJBOztBQTFCQTtFQUNBLHdCQUFBO0VBQ0EseUJBQUE7QUE2QkE7O0FBM0JBO0VBQ0Esd0JBQUE7QUE4QkE7O0FBNUJBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQStCQTs7QUE3QkE7RUFDQSx3QkFBQTtBQWdDQTs7QUE5QkE7RUFDQSwyQkFBQTtBQWlDQTs7QUEvQkE7RUFDQSwyQkFBQTtBQWtDQTs7QUFoQ0E7RUFDQSxVQUFBO0FBbUNBOztBQWpDQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FBb0NBIiwiZmlsZSI6InNyYy9hcHAvcmVxdWVzdC9yZXF1ZXN0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvb3RlcntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEwMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHNpbHZlcjtcclxufVxyXG4uYWh7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxufVxyXG4uYntcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDEyMCU7XHJcblx0YmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvcGxhaW4xLmpwZycpO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcblx0YmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuXHRiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG5cdG9wYWNpdHk6IDAuOTtcclxufVxyXG4uYXB7XHJcblx0Y29sb3I6IGJsYWNrO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHNpbHZlcjtcclxuXHRib3JkZXI6MXB4IHNvbGlkICM4MzA5MDk7XHJcblx0Ym9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG4uYXA6aG92ZXJ7XHJcblx0Y29sb3I6IHdoaXRlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICM4MzA5MDk7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCBibGFjaztcclxuXHRib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cdGJveC1zaGFkb3c6IDEwcHggMTBweCAxMHB4IGJsYWNrO1xyXG59XHJcbi5zcGFjZXJ7XHJcblx0ZmxleDoxIDEgYXV0bztcclxufVxyXG5cclxuI2Zvcm17XHJcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuXHRib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbn1cclxuLmJ0bmFhe1xyXG5cdGNvbG9yOiByZ2IoMCwxOSw3Nyk7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcblx0Ym9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuXHRib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xyXG59XHJcbi5idG5hYTpob3ZlcntcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcclxuXHRjb2xvcjogd2hpdGU7XHJcbn1cclxuLnNsaWRlcmF7XHJcblx0aGVpZ2h0OiA1MDBweDtcclxufVxyXG4uaGVhZHtcclxuXHRtYXJnaW46IDUlO1xyXG59XHJcbi5oZWFkMXs7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwyNDUsMjM5KTtcclxuXHRoZWlnaHQ6IDcwcHg7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuLm1haW57XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHJnYigyNDUsMjQ1LDIzOSk7XHJcbn1cclxuLmZpcnN0e1xyXG5cdHdpZHRoOiAzMCU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRtYXJnaW46IDIlIDIlO1xyXG5cdHBhZGRpbmc6IDIlO1xyXG5cdGJvcmRlcjoxcHggc29saWQgcmdiKDAsMTksNzcpO1xyXG5cdGJveC1zaGFkb3c6IDEwcHggMTBweCAxMHB4IHJnYigwLDE5LDc3KTtcclxufVxyXG5cclxuLnNlY29uZHtcclxuXHR3aWR0aDogMzAlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRtYXJnaW46IDIlIDElO1xyXG5cdHBhZGRpbmc6IDIlO1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRib3JkZXI6MXB4IHNvbGlkIHJnYigwLDE5LDc3KTtcclxuXHRib3gtc2hhZG93OiAxMHB4IDEwcHggMTBweCByZ2IoMCwxOSw3Nyk7XHJcblxyXG59XHJcblxyXG4udGhpcmR7XHJcblx0d2lkdGg6IDMwJTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luOiAyJSAyJTtcclxuXHRwYWRkaW5nOiAyJTtcclxuXHRib3JkZXItcmFkaXVzOiA1cHg7XHJcblx0Ym9yZGVyOjFweCBzb2xpZCByZ2IoMCwxOSw3Nyk7XHJcblx0Ym94LXNoYWRvdzogMTBweCAxMHB4IDEwcHggcmdiKDAsMTksNzcpO1xyXG59XHJcblxyXG4uaHtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLnMxe1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4uczJ7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogZ3JheTtcclxufVxyXG5cclxuLmZpcnN0OmhvdmVyLC5maXJzdDE6aG92ZXIsIC5zZWNvbmQ6aG92ZXIsLnNlY29uZDE6aG92ZXIsIC50aGlyZDpob3ZlciB7XHJcblx0XHRib3JkZXI6MnB4IHNvbGlkIHJnYigwLCAxMDIsIDE1Myk7XHJcblx0Ym94LXNoYWRvdzogMTVweCAxNXB4IDE1cHggcmdiKDAsIDEwMiwgMTUzKTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRjb2xvcjogcmdiKDAsMTksNzcpO1xyXG59XHJcbi5idG5he1xyXG5cdG1hcmdpbjogMiUgMiU7XHJcblx0Y29sb3I6IHJnYigwLDE5LDc3KTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHRib3JkZXI6IDFweCBzb2xpZCByZ2IoMCwxOSw3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogMnB4O1xyXG59XHJcblxyXG4gLmJ0bmE6aG92ZXJ7XHJcbiBcdG1hcmdpbjogMyUgMyU7XHJcblx0Y29sb3I6IGdyZWVuO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIGdyZWVuO1xyXG5cdGJvcmRlci1yYWRpdXM6IDJweDtcclxuIH1cclxuIC5mb290ZXJye1xyXG4gXHQgXHRoZWlnaHQ6IDIwMHB4O1xyXG4gXHQgXHR3aWR0aDogMTAwJTtcclxuIH1cclxuXHJcbiBcclxuI21vdmV0eHR7XHJcblx0YW5pbWF0aW9uLWR1cmF0aW9uOjIwcztcclxuXHRhbmltYXRpb24tbmFtZTogc2xpZGVpbjtcclxuXHRhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG59XHJcbkBrZXlmcmFtZXMgc2xpZGVpbntcclxuXHRmcm9te1xyXG5cdFx0bWFyZ2luLWxlZnQ6IDEwMCU7XHJcblx0XHR3aWR0aDogMzAwJTtcclxuXHR9XHJcblx0dG97XHJcblx0XHRtYXJnaW4tbGVmdDogMCU7XHJcblx0XHR3aWR0aDogMTAwJTtcclxuXHR9XHJcbn1cclxuLm1haW5kaXZ7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiA0MDBweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRwYWRkaW5nOiAxJTtcclxufVxyXG4ubGVmdHtcclxuXHR3aWR0aDogMTYlO1xyXG5cdGhlaWdodDogYXV0bztcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRmbG9hdDogbGVmdDtcclxuXHRtYXJnaW46IDElIDAlO1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIHJnYigwLCA1MSwgNzcpO1xyXG5cdGJvcmRlci1yYWRpdXM6IDVweDtcclxuXHRwYWRkaW5nOiAxJTtcclxuXHRcclxuXHJcblxyXG59XHJcbi5yaWNoeXtcclxuXHRwYWRkaW5nOiA0JTtcclxufVxyXG4uY2VudGVye1xyXG5cdHdpZHRoOiA1MyU7XHJcblx0aGVpZ2h0OiBhdXRvO1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdGZsb2F0OiBsZWZ0O1xyXG5cdG1hcmdpbjogMiU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgcmdiKDAsIDUxLCA3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdHBhZGRpbmc6MCU7XHJcblx0Ym94LXNoYWRvdzogNXB4IDVweCA1cHggNXB4IDtcclxufVxyXG4ucmlnaHR7XHJcblx0d2lkdGg6IDIwJTtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcblx0ZmxvYXQ6IHJpZ2h0O1xyXG5cdG1hcmdpbjogMiU7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgcmdiKDAsIDUxLCA3Nyk7XHJcblx0Ym9yZGVyLXJhZGl1czogNXB4O1xyXG5cdHBhZGRpbmc6IDElO1xyXG5cclxufVxyXG4uc2Nyb2xsYmFyLWRlZXAtcHVycGxlOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7IH1cclxuXHJcbi5zY3JvbGxiYXItZGVlcC1wdXJwbGU6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxud2lkdGg6IDEycHg7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7IH1cclxuXHJcbi5zY3JvbGxiYXItZGVlcC1wdXJwbGU6Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogIzUxMmRhODsgfVxyXG5cclxuLnNjcm9sbGJhci1kZWVwLXB1cnBsZSB7XHJcbnNjcm9sbGJhci1jb2xvcjogIzUxMmRhOCAjRjVGNUY1O1xyXG59XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1jeWFuOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiAxMnB4O1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1OyB9XHJcblxyXG4uc2Nyb2xsYmFyLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuYm9yZGVyLXJhZGl1czogMTBweDtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogIzAwYmNkNDsgfVxyXG5cclxuLnNjcm9sbGJhci1jeWFuIHtcclxuc2Nyb2xsYmFyLWNvbG9yOiAjMDBiY2Q0ICNGNUY1RjU7XHJcbn1cclxuXHJcbi5zY3JvbGxiYXItZHVzdHktZ3Jhc3M6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTtcclxuYm9yZGVyLXJhZGl1czogMTBweDsgfVxyXG5cclxuLnNjcm9sbGJhci1kdXN0eS1ncmFzczo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG53aWR0aDogMTJweDtcclxuYmFja2dyb3VuZC1jb2xvcjogI0Y1RjVGNTsgfVxyXG5cclxuLnNjcm9sbGJhci1kdXN0eS1ncmFzczo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWltYWdlOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgzMzBkZWcsICNkNGZjNzkgMCUsICM5NmU2YTEgMTAwJSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgxMjBkZWcsICNkNGZjNzkgMCUsICM5NmU2YTEgMTAwJSk7IH1cclxuXHJcbi5zY3JvbGxiYXItcmlwZS1tYWxpbmthOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbmJhY2tncm91bmQtY29sb3I6ICNGNUY1RjU7XHJcbmJvcmRlci1yYWRpdXM6IDEwcHg7IH1cclxuXHJcbi5zY3JvbGxiYXItcmlwZS1tYWxpbmthOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiAxMnB4O1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjRjVGNUY1OyB9XHJcblxyXG4uc2Nyb2xsYmFyLXJpcGUtbWFsaW5rYTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4td2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5iYWNrZ3JvdW5kLWltYWdlOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCgzMzBkZWcsICNmMDkzZmIgMCUsICNmNTU3NmMgMTAwJSk7XHJcbmJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCgxMjBkZWcsICNmMDkzZmIgMCUsICNmNTU3NmMgMTAwJSk7IH1cclxuXHJcbi5ib3JkZXJlZC1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IG5vbmU7XHJcbmJvcmRlcjogMXB4IHNvbGlkICM1MTJkYTg7IH1cclxuXHJcbi5ib3JkZXJlZC1kZWVwLXB1cnBsZTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4td2Via2l0LWJveC1zaGFkb3c6IG5vbmU7IH1cclxuXHJcbi5ib3JkZXJlZC1jeWFuOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbi13ZWJraXQtYm94LXNoYWRvdzogbm9uZTtcclxuYm9yZGVyOiAxcHggc29saWQgIzAwYmNkNDsgfVxyXG5cclxuLmJvcmRlcmVkLWN5YW46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcclxuLXdlYmtpdC1ib3gtc2hhZG93OiBub25lOyB9XHJcblxyXG4uc3F1YXJlOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XHJcbmJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDsgfVxyXG5cclxuLnNxdWFyZTo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG5ib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7IH1cclxuXHJcbi50aGluOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbndpZHRoOiA2cHg7IH1cclxuXHJcbi5leGFtcGxlLTEge1xyXG5wb3NpdGlvbjogcmVsYXRpdmU7XHJcbm92ZXJmbG93LXk6IHNjcm9sbDtcclxuaGVpZ2h0OiAyNTBweDsgfVxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](RequestComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-request',
                templateUrl: './request.component.html',
                styleUrls: ['./request.component.scss']
            }]
    }], function () { return [{ type: _data_restapi_service__WEBPACK_IMPORTED_MODULE_2__["RestapiService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Banks\Desktop\edocs\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map